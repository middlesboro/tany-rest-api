<?php

/*
* PrestaShop - Open Source eCommerce Solution
* @link:                www.prestashop.com
*
* @script name:         PrestaShop GP WebPay
* @purpose:             Module for accepting payments by credit and debit cards by MasterCard, VISA, 
*                       Diners Club or American Express credit and debit card, or MasterPass and MasterCard Mobile digital wallet.
* @type:                Payment module
* @author:              prestashop
* @copyright:           (c) 2001-2018 Prestashop
***************************************
*
* THIS IS COPYRIGHTED SOFTWARE
* PLEASE READ THE LICENSE AGREEMENT
* INCLUDED IN THE DISTRIBUTION PACKAGE
*
***************************************
*
*/

/**
 * @since 1.5.0
 */

class GpwebpayPaymentModuleFrontController extends ModuleFrontController
{
    public $ssl = true;
    public $display_column_left = false;
    public $display_column_right = false;

    /**
     * @see FrontController::initContent()
     */
    public function initContent()
    {
        parent::initContent();

        /*
        * Parameter values which are different
        *   - order id vs. cart id
        *   - sign
        */
        $go_payment = Tools::getValue('process');

        /*
        * Call the payment method
        *   - create an order BEFORE the payment (default)
        *   - create an order AFTER the payment
        */
        $order_method = $this->module->ORDER_METHOD;

        $cart = $this->context->cart;
        $merchant_number = Configuration::get('GPWEBPAY_MERCHANTNUMBER');

        $operation = 'CREATE_ORDER';
        $deposit_flag = (int)Configuration::get('GPWEBPAY_DEPOSITFLAG');
        $total = number_format($cart->getOrderTotal(true, 3), 2, '.', '');
        $total_converted = $total * 100; // The price must be sent in the cents (decimal sign removing)
//      $currency_cart = $this->module->getCurrency((int)$cart->id_currency);
        $currency_cart = (int)$this->context->currency->id;
//        $currency_iso = $this->context->currency->iso_code_num;
        $currency_iso = 978; //eur
        $return_url = Tools::getShopDomainSsl(true, false) . __PS_BASE_URI__ . 'index.php?fc=module&module='.$this->module->name.'&controller=response';
        $payment_url = $this->module->_bank[Configuration::get('GPWEBPAY_BANK')];

        /* Used for ORDERNUMBER paramter 
         * because must be for each payment request.
         * For PrestaShop Order ID
         * is used MERORDERNUM parameter instead
         */
        $timestamp = date('YmdHis', time());

        if (Configuration::get('GPWEBPAY_LIVE_FLAG') == '0') {
            $payment_url = str_replace('https://3dsecure', 'https://test.3dsecure', $payment_url);
        }

        if (isset($go_payment) && $go_payment == 'pay') {
            /* Create a new order with Waiting status: get Order ID from DB */
            $customer = new Customer((int)$cart->id_customer);
            $this->module->validateOrder(
                                        (int)$cart->id, 
                                        (int)Configuration::get('GPWEBPAY_STATUS_AWAITING'), 
                                        $total, 
                                        $this->module->displayName, 
                                        $this->module->getL('msg_payment'),
                                        array(), 
                                        $currency_cart, 
                                        false, 
                                        $customer->secure_key);

            $order = new Order($this->module->currentOrder); // Just created order
            $order_id = (int)($order->id);
            $md = Order::getCartIdStatic((int)($order->id));
            $order_ref = (int)($order->reference);
        } else {
            /* Order doen't exist yet: Order ID = Cart ID */
            $order_id = (int)($cart->id);
            $md = (int)($cart->id);
            $order_ref = '';
        }

        /* Product description */
        $products = $cart->getProducts();
        $description = array();
        foreach ($products as $product) {
            $description[] = $product['name'];
        }
        $description = implode(';', $description);

        $description = $this->toASCII($description);
        $description = trim(substr($description, 0, 255));

        $addInfo = $this->createAddinfo($cart);
        $addInfo = $this->removeCrLfTabTrim($addInfo);

        /* Build signature input */
        $source_for_sign = $merchant_number . "|" .
                            $operation . "|" .
                            $timestamp . "|" .
                            $total_converted . "|" .
                            $currency_iso . "|" .
                            $deposit_flag . "|" .
                            $order_id . "|" .
                            $return_url . "|" .
                            $description . "|" .
                            $md . "|" .
                            $addInfo;


        // Loading Public Key from the file
        if (Configuration::get('GPWEBPAY_LIVE_FLAG') == '1') {
            $verejny_kluc = GPWEBPAY_CERT_PUBLIC;
        } else {
            $verejny_kluc = GPWEBPAY_CERT_PUBLIC_TEST;
        }

        if (Configuration::get('GPWEBPAY_LIVE_FLAG'.$this->module->extraCurrency) == '1') {
            $test_suffix = '';
        } else {
            $test_suffix = '_TEST';
        }

        $privatny_kluc = Configuration::get('GPWEBPAY_PRIVATE_KEY'.$test_suffix);

        /* Create signature */
        $CSignature = new CSignature($privatny_kluc, $this->module->gp_password, $verejny_kluc);
        $sign = $CSignature->sign($source_for_sign);

        $data = array();
        $data['MERCHANTNUMBER'] = $merchant_number;
        $data['OPERATION'] = $operation;
        $data['ORDERNUMBER'] = $timestamp;
        $data['AMOUNT'] = $total_converted;
        $data['CURRENCY'] = $currency_iso;
        $data['DEPOSITFLAG'] = $deposit_flag;
        $data['URL'] = $return_url;
        $data['DESCRIPTION'] = $description;
        $data['MD'] = $md;
        $data['MERORDERNUM'] = $order_id;
        $data['DIGEST'] = $sign;
        $data['ADDINFO'] = $addInfo;

        /* Redirect on GP WebPay gateway with payment request */
        $getfs = "<form id='form' method='post' action='".$payment_url."' accept-charset='UTF-8' enctype='application/x-www-form-urlencoded'>\n";
        foreach ($data as $n => $v) {
            $getfs .= "<input type='hidden' name='$n' value='".$v."'>\n";
        }
        $getfs .= "</form>";
        $getfs .= "<script>document.getElementById(\"form\").submit();</script>";

        echo $getfs;
    }

    private function removeCrLfTabTrim($s) {
        $s = trim(str_replace("\t"," ",str_replace("\r","",str_replace("\n"," ",$s))));
        return $s;
    }

    private function createAddinfo($cart) {
        $customer = new Customer($cart->id_customer);
//        $deliveryAddress = new Address($cart->id_address_delivery);
        $invoiceAddress = new Address($cart->id_address_invoice);

        $isoCountryToNum = array('AF'=>'004','AX'=>'248','AL'=>'008','DZ'=>'012','AS'=>'016','AD'=>'020','AO'=>'024','AI'=>'660','AQ'=>'010','AG'=>'028','AR'=>'032','AM'=>'051','AW'=>'533','AU'=>'036','AT'=>'040','AZ'=>'031','BS'=>'044','BH'=>'048','BD'=>'050','BB'=>'052','BY'=>'112','BE'=>'056','BZ'=>'084','BJ'=>'204','BM'=>'060','BT'=>'064','BO'=>'068','BQ'=>'535','BA'=>'070','BW'=>'072','BV'=>'074','BR'=>'076','IO'=>'086','BN'=>'096','BG'=>'100','BF'=>'854','BI'=>'108','CV'=>'132','KH'=>'116','CM'=>'120','CA'=>'124','KY'=>'136','CF'=>'140','TD'=>'148','CL'=>'152','CN'=>'156','CX'=>'162','CC'=>'166','CO'=>'170','KM'=>'174','CG'=>'178','CD'=>'180','CK'=>'184','CR'=>'188','CI'=>'384','HR'=>'191','CU'=>'192','CW'=>'531','CY'=>'196','CZ'=>'203','DK'=>'208','DJ'=>'262','DM'=>'212','DO'=>'214','EC'=>'218','EG'=>'818','SV'=>'222','GQ'=>'226','ER'=>'232','EE'=>'233','SZ'=>'748','ET'=>'231','FK'=>'238','FO'=>'234','FJ'=>'242','FI'=>'246','FR'=>'250','GF'=>'254','PF'=>'258','TF'=>'260','GA'=>'266','GM'=>'270','GE'=>'268','DE'=>'276','GH'=>'288','GI'=>'292','GR'=>'300','GL'=>'304','GD'=>'308','GP'=>'312','GU'=>'316','GT'=>'320','GG'=>'831','GN'=>'324','GW'=>'624','GY'=>'328','HT'=>'332','HM'=>'334','VA'=>'336','HN'=>'340','HK'=>'344','HU'=>'348','IS'=>'352','IN'=>'356','ID'=>'360','IR'=>'364','IQ'=>'368','IE'=>'372','IM'=>'833','IL'=>'376','IT'=>'380','JM'=>'388','JP'=>'392','JE'=>'832','JO'=>'400','KZ'=>'398','KE'=>'404','KI'=>'296','KP'=>'408','KR'=>'410','KW'=>'414','KG'=>'417','LA'=>'418','LV'=>'428','LB'=>'422','LS'=>'426','LR'=>'430','LY'=>'434','LI'=>'438','LT'=>'440','LU'=>'442','MO'=>'446','MG'=>'450','MW'=>'454','MY'=>'458','MV'=>'462','ML'=>'466','MT'=>'470','MH'=>'584','MQ'=>'474','MR'=>'478','MU'=>'480','YT'=>'175','MX'=>'484','FM'=>'583','MD'=>'498','MC'=>'492','MN'=>'496','ME'=>'499','MS'=>'500','MA'=>'504','MZ'=>'508','MM'=>'104','NA'=>'516','NR'=>'520','NP'=>'524','NL'=>'528','NC'=>'540','NZ'=>'554','NI'=>'558','NE'=>'562','NG'=>'566','NU'=>'570','NF'=>'574','MK'=>'807','MP'=>'580','NO'=>'578','OM'=>'512','PK'=>'586','PW'=>'585','PS'=>'275','PA'=>'591','PG'=>'598','PY'=>'600','PE'=>'604','PH'=>'608','PN'=>'612','PL'=>'616','PT'=>'620','PR'=>'630','QA'=>'634','RE'=>'638','RO'=>'642','RU'=>'643','RW'=>'646','BL'=>'652','SH'=>'654','KN'=>'659','LC'=>'662','MF'=>'663','PM'=>'666','VC'=>'670','WS'=>'882','SM'=>'674','ST'=>'678','SA'=>'682','SN'=>'686','RS'=>'688','SC'=>'690','SL'=>'694','SG'=>'702','SX'=>'534','SK'=>'703','SI'=>'705','SB'=>'090','SO'=>'706','ZA'=>'710','GS'=>'239','SS'=>'728','ES'=>'724','LK'=>'144','SD'=>'729','SR'=>'740','SJ'=>'744','SE'=>'752','CH'=>'756','SY'=>'760','TW'=>'158','TJ'=>'762','TZ'=>'834','TH'=>'764','TL'=>'626','TG'=>'768','TK'=>'772','TO'=>'776','TT'=>'780','TN'=>'788','TR'=>'792','TM'=>'795','TC'=>'796','TV'=>'798','UG'=>'800','UA'=>'804','AE'=>'784','GB'=>'826','US'=>'840','UM'=>'581','UY'=>'858','UZ'=>'860','VU'=>'548','VE'=>'862','VN'=>'704','VG'=>'092','VI'=>'850','WF'=>'876','EH'=>'732','YE'=>'887','ZM'=>'894','ZW'=>'716');

        $xaddInfo = '<?xml version="1.0" encoding="UTF-8"?>
			<additionalInfoRequest xmlns="http://gpe.cz/gpwebpay/additionalInfo/request" version="4.0">
			  <cardholderInfo>
				<cardholderDetails/>
				<billingDetails/>
				<shippingDetails/>
			  </cardholderInfo>
			</additionalInfoRequest>
			';

        $name = $customer->firstname . ' ' . $customer->lastname;
        $name = mb_substr($name, 0, 45);
        if (strlen($name) < 2) $name = $name + ' ';

        $address = mb_substr($invoiceAddress->address1, 0, 50);
        $city = mb_substr($invoiceAddress->city, 0, 50);
        $postalCode = mb_substr($invoiceAddress->postcode, 0, 16);
        $country = $isoCountryToNum["SK"];

        $xml = simplexml_load_string($xaddInfo);
        $xml->cardholderInfo->cardholderDetails->addChild("name", $name);
        $xml->cardholderInfo->cardholderDetails->addChild("email", $customer->email);

        $xml->cardholderInfo->billingDetails->addChild("name", $name);
        $xml->cardholderInfo->billingDetails->addChild("address1", $address);
        $xml->cardholderInfo->billingDetails->addChild("city", $city);
        $xml->cardholderInfo->billingDetails->addChild("postalCode", $postalCode);
        $xml->cardholderInfo->billingDetails->addChild("country", $country);

        $xml->cardholderInfo->shippingDetails->addChild("name", $name);
        $xml->cardholderInfo->shippingDetails->addChild("address1", $address);
        $xml->cardholderInfo->shippingDetails->addChild("city", $city);
        $xml->cardholderInfo->shippingDetails->addChild("postalCode", $postalCode);
        $xml->cardholderInfo->shippingDetails->addChild("country", $country);

        $str = $xml->asXML();

        return $str;
    }

    private function toASCII($string) {
        $string = strtr($string, array(
            'ä'=>'a', 'Ä'=>'A', 'á'=>'a', 'Á'=>'A', 'à'=>'a', 'À'=>'A', 'ã'=>'a', 'Ã'=>'A', 'â'=>'a', 'Â'=>'A', 'č'=>'c', 'Č'=>'C', 'ć'=>'c', 'Ć'=>'C', 'ď'=>'d', 'Ď'=>'D', 'ě'=>'e', 'Ě'=>'E', 'é'=>'e', 'É'=>'E', 'ë'=>'e', 'Ë'=>'E', 'è'=>'e', 'È'=>'E', 'ê'=>'e', 'Ê'=>'E', 'í'=>'i', 'Í'=>'I', 'ï'=>'i', 'Ï'=>'I', 'ì'=>'i', 'Ì'=>'I', 'î'=>'i', 'Î'=>'I', 'ľ'=>'l', 'Ľ'=>'L', 'ĺ'=>'l', 'Ĺ'=>'L', 'ń'=>'n', 'Ń'=>'N', 'ň'=>'n', 'Ň'=>'N', 'ñ'=>'n', 'Ñ'=>'N', 'ó'=>'o', 'Ó'=>'O', 'ö'=>'o', 'Ö'=>'O', 'ô'=>'o', 'Ô'=>'O', 'ò'=>'o', 'Ò'=>'O', 'õ'=>'o', 'Õ'=>'O', 'ő'=>'o', 'Ő'=>'O', 'ř'=>'r', 'Ř'=>'R', 'ŕ'=>'r', 'Ŕ'=>'R', 'š'=>'s', 'Š'=>'S', 'ś'=>'s', 'Ś'=>'S', 'ť'=>'t', 'Ť'=>'T', 'ú'=>'u', 'Ú'=>'U', 'ů'=>'u', 'Ů'=>'U', 'ü'=>'u', 'Ü'=>'U', 'ù'=>'u', 'Ù'=>'U', 'ũ'=>'u', 'Ũ'=>'U', 'û'=>'u', 'Û'=>'U', 'ý'=>'y', 'Ý'=>'Y', 'ž'=>'z', 'Ž'=>'Z', 'ź'=>'z', 'Ź'=>'Z',
            'а' => 'a', 'б' => 'b', 'в' => 'v', 'г' => 'g', 'д' => 'd', 'е' => 'e', 'ё' => 'jo', 'ж' => 'zh', 'з' => 'z', 'и' => 'i', 'й' => 'jj', 'к' => 'k', 'л' => 'l', 'м' => 'm', 'н' => 'n', 'о' => 'o', 'п' => 'p', 'р' => 'r', 'с' => 's', 'т' => 't', 'у' => 'u', 'ф' => 'f', 'х' => 'kh', 'ц' => 'c', 'ч' => 'ch', 'ш' => 'sh', 'щ' => 'shh', 'ъ' => '', 'ы' => 'y', 'ь' => '', 'э' => 'eh', 'ю' => 'ju', 'я' => 'ja',
            'А' => 'A', 'Б' => 'B', 'В' => 'V', 'Г' => 'G', 'Д' => 'D', 'Е' => 'E', 'Ё' => 'JO', 'Ж' => 'ZH', 'З' => 'Z', 'И' => 'I', 'Й' => 'JJ', 'К' => 'K', 'Л' => 'L', 'М' => 'M', 'Н' => 'N', 'О' => 'O', 'П' => 'P', 'Р' => 'R', 'С' => 'S', 'Т' => 'T', 'У' => 'U', 'Ф' => 'F', 'Х' => 'KH', 'Ц' => 'C', 'Ч' => 'CH', 'Ш' => 'SH', 'Щ' => 'SHH', 'Ъ' => '', 'Ы' => 'Y', 'Ь' => '', 'Э' => 'EH', 'Ю' => 'JU', 'Я' => 'JA',
        ));
        $orig_lc_ctype  = setlocale( LC_CTYPE, 0 );
        setlocale(LC_CTYPE, 'en_GB');
        $string = iconv('UTF-8', 'ASCII//TRANSLIT//IGNORE', $string);
        $string = str_replace("'","",$string);
        setlocale(LC_CTYPE, $orig_lc_ctype);

        return $string;
    }

}