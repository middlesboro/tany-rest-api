<?php

/*
* PrestaShop - Open Source eCommerce Solution
* @link:                www.prestashop.com
*
* @script name:         PrestaShop GP WebPay
* @purpose:             Module for accepting payments by credit and debit cards by MasterCard, VISA, 
*                       Diners Club or American Express credit and debit card, or MasterPass and MasterCard Mobile digital wallet.
* @type:                Payment module
* @author:              prestashop
* @copyright:           (c) 2001-2018 Prestashop
***************************************
*
* THIS IS COPYRIGHTED SOFTWARE
* PLEASE READ THE LICENSE AGREEMENT
* INCLUDED IN THE DISTRIBUTION PACKAGE
*
***************************************
*
*/

class GpwebpayNotificationModuleFrontController extends ModuleFrontController 
{
    public $ssl = true;
    public $display_column_left = false;
    public $display_column_right = false;

    /**
    * @see FrontController::initContent()
    */
    public function initContent()
    {
        parent::initContent();

        $cart = $this->context->cart;

        $this->context->smarty->assign(array(
            'nbProducts' => $cart->nbProducts(),
            'order_id' => Tools::getValue('order'),
            'prcode' => Tools::getValue('prcode'),
            'srcode' => Tools::getValue('srcode'),
//          'payment_status' => Tools::getValue('status'),
            'contact_url' => $this->context->link->getPageLink('contact', true),
            'history_url' => $this->context->link->getPageLink('history', true),
            'order_url' => $this->context->link->getPageLink('order', null, null, 'step=3'),
            'payment_logo' => Media::getMediaPath(_PS_MODULE_DIR_.$this->module->name.'/views/img/'.$this->module->name.'-logo.png'),
            'card_logos' => Media::getMediaPath(_PS_MODULE_DIR_.$this->module->name.'/views/img/'.$this->module->name.'-cards.png'),
        ));

        $this->setTemplate('module:gpwebpay/views/templates/front/notification.tpl');
    }
}