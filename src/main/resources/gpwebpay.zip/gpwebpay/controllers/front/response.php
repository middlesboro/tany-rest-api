<?php

/*
* PrestaShop - Open Source eCommerce Solution
* @link:                www.prestashop.com
*
* @script name:         PrestaShop GP WebPay
* @purpose:             Module for accepting payments by credit and debit cards by MasterCard, VISA, 
*                       Diners Club or American Express credit and debit card, or MasterPass and MasterCard Mobile digital wallet.
* @type:                Payment module
* @author:              prestashop
* @copyright:           (c) 2001-2018 Prestashop
***************************************
*
* THIS IS COPYRIGHTED SOFTWARE
* PLEASE READ THE LICENSE AGREEMENT
* INCLUDED IN THE DISTRIBUTION PACKAGE
*
***************************************
*
*/

/**
 * @since 1.5.0
 */

//include(dirname(__FILE__).'/../../../config/config.inc.php');
//include(dirname(__FILE__).'/../../../init.php');
//require_once(dirname(__FILE__).'/../gpwebpay.php');

class GpwebpayResponseModuleFrontController extends ModuleFrontController
{
    public $ssl = true;
    public $display_column_left = false;
    public $display_column_right = false;

    /**
     * @see FrontController::initContent()
     */
    public function initContent()
    {
        parent::initContent();

        $errors = '';
        $msg = '';
        $gpwebpay = new Gpwebpay();

        $debug = Configuration::get('GPWEBPAY_DEBUG');
        $order_method = Configuration::get('GPWEBPAY_ORDER_METHOD'); // values: before / after

        /* 1. BUILDING VARIABLES FROM RETURN URL */
        /* IMPORTANT: DO NOT USE (int)($_GET['VALUE']) BECAUSE IT REMOVE 0 FROM THE STRING BEGINING! */

        /* MANDATORY VARIABLES */
        $var_operation       = Tools::getValue('OPERATION'); // Operation type
        $var_ordernumber     = Tools::getValue('ORDERNUMBER'); // Timestamp
        $var_merordernum     = Tools::getValue('MERORDERNUM'); // Order number
        $var_md              = Tools::getValue('MD'); // MD (Cart ID)
        $var_prcode          = Tools::getValue('PRCODE'); // PR code
        $var_srcode          = Tools::getValue('SRCODE'); // SR code
        $var_digest          = Tools::getValue('DIGEST'); // Signature
        $var_digest1         = Tools::getValue('DIGEST1'); // Signature 1

        /* OPTIONAL VARIABLES */
        $var_resulttext      = Tools::getValue('RESULTTEXT'); // Result text
        $var_userparam1      = Tools::getValue('USERPARAM1');
        $var_addinfo         = Tools::getValue('ADDINFO');

        if ($order_method == 'before') {
            /* 2A. LOAD INFO ABOUT AN ORDER */
            // Get ID cart from ID order
            $cart_id = Order::getCartIdStatic((int)($var_merordernum));
            $cart = new Cart((int)($cart_id));
            $total = (float)(number_format($cart->getOrderTotal(true, 3), 2, '.', ''));
            $customer = new Customer((int)$cart->id_customer);
        } else {
            /* 2B. GET OTHER VARIABLES */
            $cart = new Cart((int)($var_merordernum));
            $total = (float)(number_format($cart->getOrderTotal(true, 3), 2, '.', ''));
            $customer = new Customer((int)$cart->id_customer);
        }

        /* GET CART ID FROM MODULE DB TABLE BY ORDERNUMBER */
        /*
        $sql = 'SELECT CURRENCY, MD cart_id FROM `'._DB_PREFIX_.'gpwebpay_log` WHERE id='.(int)$var_merordernum;
        $db = Db::getInstance();
        $res = $db->ExecuteS($sql);
        $cart = new Cart((int)$res[0]["cart_id"]);


        /* 3. CREATE SIGNATURE */
        $CURRENCY = $gpwebpay->keys($cart->id_currency);

        if (Configuration::get('GPWEBPAY_LIVE_FLAG')) {
            $verejny = GPWEBPAY_CERT_PUBLIC;
        } else {
            $verejny = GPWEBPAY_CERT_PUBLIC_TEST;
        }

        /* 4. BUILD SIGNATURE STRING */
// OPERATION | ORDERNUMBER | MERORDERNUM | MD | PRCODE | SRCODE | RESULTTEXT | USERPARAM1 | ADDINFO

        $text = $var_operation.'|'.$var_ordernumber;

        if (isset($_GET['MERORDERNUM']) && !empty($_GET['MERORDERNUM'])) {
            $text .= '|'.$var_merordernum;
        }

        if (isset($_GET['MD']) && !empty($_GET['MD'])) {
            $text .= '|'.$var_md;
        }

        $text .= '|'.$var_prcode.'|'.$var_srcode;

        if (isset($_GET['RESULTTEXT']) && !empty($_GET['RESULTTEXT'])) {
            $text .= '|'.$var_resulttext;
        }

        $signature = $var_digest;
        $podpis = new CSignature(null, null, $verejny);
        $podpis->verejny = $verejny;
        $result = $podpis->verify($text, $signature);
        $result2 = $podpis->verify($text.'|'.Configuration::get('GPWEBPAY_MERCHANTNUMBER'.$gpwebpay->extraCurrency), $var_digest1);

        /* 5. DELIMETER FOR PRIVATE MESSAGE*/
        if ($order_method == 'before') {
            $delimeter = '<br> ';
        } else {
            $delimeter = ' *** ';
        }

        /* 6. PR CODE ASSIGNATION */
        $msg_pr = '';
        if ($var_prcode == '0') {
            $msg_pr .= $gpwebpay->getL('msg_prcode_0');
        }
        else
        {
            if ($var_prcode == '1') {
                $msg_pr .= $gpwebpay->getL('msg_prcode_1');
            } elseif ($var_prcode == '2') {
                $msg_pr .= $gpwebpay->getL('msg_prcode_2');
            } elseif ($var_prcode == '3') {
                $msg_pr .= $gpwebpay->getL('msg_prcode_3');
            } elseif ($var_prcode == '4') {
                $msg_pr .= $gpwebpay->getL('msg_prcode_4');
            } elseif ($var_prcode == '5') {
                $msg_pr .= $gpwebpay->getL('msg_prcode_5');
            } elseif ($var_prcode == '11') {
                $msg_pr .= $gpwebpay->getL('msg_prcode_11');
            } elseif ($var_prcode == '14') {
                $msg_pr .= $gpwebpay->getL('msg_prcode_15');
            } elseif ($var_prcode == '15') {
                $msg_pr .= $gpwebpay->getL('msg_prcode_15');
            } elseif ($var_prcode == '17') {
                $msg_pr .= $gpwebpay->getL('msg_prcode_17');
            } elseif ($var_prcode == '18') {
                $msg_pr .= $gpwebpay->getL('msg_prcode_18');
            } elseif ($var_prcode == '20') {
                $msg_pr .= $gpwebpay->getL('msg_prcode_20');
            } elseif ($var_prcode == '25') {
                $msg_pr .= $gpwebpay->getL('msg_prcode_25');
            } elseif ($var_prcode == '26') {
                $msg_pr .= $gpwebpay->getL('msg_prcode_26');
            } elseif ($var_prcode == '27') {
                $msg_pr .= $gpwebpay->getL('msg_prcode_27');
            } elseif ($var_prcode == '28') {
                $msg_pr .= $gpwebpay->getL('msg_prcode_28');
            } elseif ($var_prcode == '30') {
                $msg_pr .= $gpwebpay->getL('msg_prcode_30');
            } elseif ($var_prcode == '31') {
                $msg_pr .= $gpwebpay->getL('msg_prcode_31');
            } elseif ($var_prcode == '35') {
                $msg_pr .= $gpwebpay->getL('msg_prcode_35');
            } elseif ($var_prcode == '50') {
                $msg_pr .= $gpwebpay->getL('msg_prcode_50');
            } elseif ($var_prcode == '200') {
                $msg_pr .= $gpwebpay->getL('msg_prcode_200');
            } elseif ($var_prcode == '1000') {
                $msg_pr .= $gpwebpay->getL('msg_prcode_1000');
            } else {
                $msg_pr .= $gpwebpay->getL('msg_prcode_unknown');
            }
        }

        /* 7. SR CODE ASSIGNATION */
        $msg_sr = '';
        if ($var_prcode == '0') {
            $msg_sr .= $gpwebpay->getL('msg_srcode_0');
        } elseif ($var_prcode == '1' || $var_prcode == '2' || $var_prcode == '3' || $var_prcode == '4' || $var_prcode == '5' || $var_prcode == '15' || $var_prcode == '20') {
            if ($var_srcode == '1') {
                $msg_sr .= $gpwebpay->getL('msg_srcode_1');
            } elseif ($var_srcode == '2') {
                $msg_sr .= $gpwebpay->getL('msg_srcode_2');
            } elseif ($var_srcode == '6') {
                $msg_sr .= $gpwebpay->getL('msg_srcode_6');
            } elseif ($var_srcode == '7') {
                $msg_sr .= $gpwebpay->getL('msg_srcode_7');
            } elseif ($var_srcode == '8') {
                $msg_sr .= $gpwebpay->getL('msg_srcode_8');
            } elseif ($var_srcode == '10') {
                $msg_sr .= $gpwebpay->getL('msg_srcode_10');
            } elseif ($var_srcode == '11') {
                $msg_sr .= $gpwebpay->getL('msg_srcode_11');
            } elseif ($var_srcode == '12') {
                $msg_sr .= $gpwebpay->getL('msg_srcode_12');
            } elseif ($var_srcode == '18') {
                $msg_sr .= $gpwebpay->getL('msg_srcode_18');
            } elseif ($var_srcode == '22') {
                $msg_sr .= $gpwebpay->getL('msg_srcode_22');
            } elseif ($var_srcode == '24') {
                $msg_sr .= $gpwebpay->getL('msg_srcode_24');
            } elseif ($var_srcode == '25') {
                $msg_sr .= $gpwebpay->getL('msg_srcode_25');
            } elseif ($var_srcode == '26') {
                $msg_sr .= $gpwebpay->getL('msg_srcode_26');
            } elseif ($var_srcode == '34') {
                $msg_sr .= $gpwebpay->getL('msg_srcode_34');
            }
        } elseif ($var_prcode == '28') {
            if ($var_srcode == '3000') {
                $msg_sr .= $gpwebpay->getL('msg_srcode_3000');
            } elseif ($var_srcode == '3001') {
                $msg_sr .= $gpwebpay->getL('msg_srcode_3001');
            } elseif ($var_srcode == '3002') {
                $msg_sr .= $gpwebpay->getL('msg_srcode_3002');
            } elseif ($var_srcode == '3004') {
                $msg_sr .= $gpwebpay->getL('msg_srcode_3004');
            } elseif ($var_srcode == '3005') {
                $msg_sr .= $gpwebpay->getL('msg_srcode_3005');
            } elseif ($var_srcode == '3006') {
                $msg_sr .= $gpwebpay->getL('msg_srcode_3006');
            } elseif ($var_srcode == '3007') {
                $msg_sr .= $gpwebpay->getL('msg_srcode_3007');
            } elseif ($var_srcode == '3008') {
                $msg_sr .= $gpwebpay->getL('msg_srcode_3008');
            }
        } elseif ($var_prcode == '30') {
            if ($var_srcode == '1001') {
                $msg_sr .= $gpwebpay->getL('msg_srcode_1001');
            } elseif ($var_srcode == '1001') {
                $msg_sr .= $gpwebpay->getL('msg_srcode_1002');
            } elseif ($var_srcode == '1002') {
                $msg_sr .= $gpwebpay->getL('msg_srcode_1003');
            } elseif ($var_srcode == '1004') {
                $msg_sr .= $gpwebpay->getL('msg_srcode_1004');
            } elseif ($var_srcode == '1005') {
                $msg_sr .= $gpwebpay->getL('msg_srcode_1005');
            }
        } else {
            $msg_sr .= $gpwebpay->getL('msg_srcode_unknown');
        }

        if ($debug == '1') {
            /* GP WEBPAY DEBUG MODE */
            echo '<div style="padding: 30px; font-family: Arial;">';
            echo '<h1>GP WEBPAY DEBUGGING MODE</h1>';

            if ($result == '1' && $result2 == '1') {
                echo '<h2 style="color: #00b000;">Great! Verification was successfull.</h2>';
            } else {
                echo '<h2 style="color: #e2184b;">Error! Verification failed.</h2>';
            }

            echo '<h2>MODULE SETTINGS</h2>';
            echo 'PAYMENT METHOD = '.$order_method.'<br>';

            echo '<h2>MANDATORY VARIABLES FROM RETURN URL</h2>';
            echo 'OPERATION = '.$var_operation.'<br>';
            echo 'ORDERNUMBER (Timestamp) = '.$var_ordernumber.'<br>';
            echo 'MERORDERNUM (Order ID) = '.$var_merordernum.'<br>';
            echo 'MD (Cart ID) = '.$var_md.'<br>';
            echo 'PRCODE = '.$var_prcode.'<br>';
            echo 'SRCODE = '.$var_srcode.'<br>';
            echo 'DIGEST = <br><strong style="color: #168ac9;">'.$var_digest.'</strong><br><br>';
            echo 'DIGEST1 = <br>'.$var_digest1.'<br>';

            echo '<h2>OPTIONAL VARIABLES FROM RETURN URL</h2>';
            echo 'RESULTTEXT = '.$var_resulttext.'<br>';
            echo 'USERPARAM1 = '.$var_userparam1.'<br>';
            echo 'ADDINFO = '.$var_addinfo;

            echo '<h2>INPUT FOR SIGNATURE</h2>';
            echo 'Parameters order: OPERATION | ORDERNUMBER | MERORDERNUM | MD | PRCODE | SRCODE | RESULTTEXT<br><br>';
            echo '$text = '.$text;

            echo '<h2>RESULTS</h2>';
            echo 'signature (created by module - must be the same as DIGEST above) = 
    <br><strong style="color: #168ac9;">'.$signature.'</strong><br><br>';

            echo 'Result = '.$result. '<br><br>';
            echo 'Result 2 = '.$result2. '<br><br>';
            echo 'PR code = '.$msg_pr. '<br><br>';
            echo 'SR code = '.$msg_sr;

            echo '<h2>VARIABLES FROM MODULE</h2>';
            echo 'ORDER CURRENCY = '.$CURRENCY.'<br><br>';
            echo 'EXTRA CURRENCY = '.$gpwebpay->extraCurrency.'<br><br>';
            echo 'PUBLIC KEY = <br>'.$verejny;
            echo '</div>';

        } else {

            /* LIVE MODE */
            /* 7. PROCESSING OF RESPONSE */
            if ($var_prcode == '0') {

                if ($result != '1' || $result2 != '1') {
                    $errors .= $gpwebpay->getL('msg_not_verified').'<br>';
                }
                if (!isset($var_operation) OR $var_operation != 'CREATE_ORDER') {
                    $errors .= $gpwebpay->getL('msg_error_operation').'<br>';
                }
                if (!isset($var_ordernumber)) {
                    $errors .= $gpwebpay->getL('msg_error_ordernumber').'<br>';
                }
                if (!isset($var_merordernum)) {
                    $errors .= $gpwebpay->getL('msg_error_merordernum').'<br>';
                }
                if (!isset($var_prcode)) {
                    $errors .= $gpwebpay->getL('msg_error_prcode').'<br>';
                }
                if (!isset($var_srcode)) {
                    $errors .= $gpwebpay->getL('msg_error_srcode').'<br>';
                }
                if (!isset($var_md)) {
                    $errors .= $gpwebpay->getL('msg_error_md').'<br>';
                }
                if (!isset($var_digest)) {
                    $errors .= $gpwebpay->getL('msg_error_digest').'<br>';
                }
                if (!isset($var_digest1)) {
                    $errors .= $gpwebpay->getL('msg_error_digest1').'<br>';
                }

                /* 8. BUILD PRIVATE MESSAGES (PM) */
                /* 8.1 PM - Payment info */
                $msg .= $gpwebpay->getL('msg_paymentinfo').$delimeter;
                if (isset($var_resulttext)) {
                    $msg .= $gpwebpay->getL('msg_resulttext').' '.$var_resulttext.$delimeter;
                }
                $msg .= $gpwebpay->getL('msg_merordernum').' '.$var_merordernum.$delimeter;
                $msg .= $gpwebpay->getL('msg_md').' '.$var_md.$delimeter;
                $msg .= $gpwebpay->getL('msg_ordernumber').' '.$var_ordernumber.$delimeter;
                $msg .= $gpwebpay->getL('msg_prcode').' '.$var_prcode.' ('.$msg_pr.')'.$delimeter;
                $msg .= $gpwebpay->getL('msg_srcode').' '.$var_srcode.' ('.$msg_sr.')'.$delimeter.'<br> ';

                /* 7A. CREATE AN ORDER FROM CART + SUCCESS MESSAGE */
                if (empty($errors)) {

                    if ($order_method == 'before') {

                        /* ADD PRIVATE MESSAGE INTO EXISTING ORDER */
                        $order_status = (int)Configuration::get('GPWEBPAY_STATUS_OK');

                    } else {

//                        /* CREATE AN ORDER FROM CART + PAYMENT ACCEPTED */
//                        $gpwebpay->validateOrder(
//                            (int)$var_merordernum,
//                            (int)Configuration::get('GPWEBPAY_STATUS_OK'),
//                            $total,
//                            $gpwebpay->displayName,
//                            $msg,
//                            array(),
//                            null,
//                            false,
//                            $customer->secure_key);

                    }
                }

            } else {

                /* 7B. FAIL MESSAGE (WITHOUT CREATING AN ORDER) */$order_status = (int)Configuration::get('GPWEBPAY_STATUS_FAIL');

                if ($order_method == 'before') {

                    $order_status = (int)Configuration::get('GPWEBPAY_STATUS_FAIL');
                    $msg .= $gpwebpay->getL('msg_prcode').' '.$var_prcode.' ('.$msg_pr.')'.$delimeter;
                    $msg .= $gpwebpay->getL('msg_srcode').' '.$var_srcode.' ('.$msg_sr.')'.$delimeter;

                } else {

                    /* 7B. FAIL MESSAGE (WITHOUT CREATING AN ORDER) */
                    $errors .= $gpwebpay->getL('msg_verify');

                }

            }

            /* 7D. CREATE AN ORDER FROM CART + ERROR MESSAGE */
            if (!empty($errors) AND isset($var_merordernum)) {

                if ($order_method == 'before') {

                    $order_status = (int)Configuration::get('GPWEBPAY_STATUS_FAIL');

                } else {

                }
            }

            if ($order_method == 'before') {

                /* UPDATING gpwebpay_log DP TABLE */
                $db = Db::getInstance();

                $sql = 'UPDATE `'._DB_PREFIX_.'gpwebpay_log` 
                SET '.' 
                    PRCODE = "'.$db->_escape($var_prcode).'", 
                    SRCODE = "'.$db->_escape($var_srcode).'", 
                    RESULTTEXT = "'.$db->_escape($var_resulttext).'", 
                    DIGEST = "'.$db->_escape($var_digest).'", 
                    DIGEST1 = "'.$db->_escape($var_digest1).'", 
                    payment_start = NOW(), 
                    timestamp = NOW()'.' 
                WHERE ORDERNUMBER = '.$var_ordernumber;

                $update = $db->Execute($sql);

                /* CHANGE AN ORDER STATUS */
                $history = new OrderHistory();
                $history->id_order = (int)($var_merordernum);
                $history->changeIdOrderState($order_status, $history->id_order);
                $history->addWithemail();

                /* Add private message */
                if (!empty($errors)) {
                    $gpwebpay->_addNewPrivateMessage((int)$var_merordernum, (int)$var_md, Context::getContext()->customer->id, $errors);
                } else {
                    $gpwebpay->_addNewPrivateMessage((int)$var_merordernum, (int)$var_md, Context::getContext()->customer->id, $msg);
                }

                if ($var_prcode == '0') {
//          $var_prcode = 'OK'
                }

                /* Redirect */
                $link = Context::getContext()->link->getModuleLink('gpwebpay', 'notification');
                $link .= '?order='.$var_merordernum.'&prcode='.$var_prcode.'&srcode='.$var_srcode;
                Tools::redirect($link);

            } else {
                if (empty($errors)) {
                    $gpwebpay->validateOrder(
                        (int)$var_merordernum,
                        (int)Configuration::get('GPWEBPAY_STATUS_OK'),
                        $total,
                        $gpwebpay->displayName,
                        $msg,
                        array(),
                        null,
                        false,
                        $customer->secure_key);

                    /* 8. REDIRECT CUSTOMER ON RETURN PAGE */
                    Tools::redirect('index.php?controller=order-confirmation&id_cart='.$cart->id.'&id_module='.$gpwebpay->id.'&id_order='.$gpwebpay->currentOrder.'&key='.$customer->secure_key);
                } else {
                    $this->setTemplate('checkout/order-payment-error');
                }
            }
        }
    }

    protected function getBreadcrumbLinks()
    {
        $breadcrumb = array();

        $breadcrumb['links'][] = array(
            'title' => $this->getTranslator()->trans('Home', array(), 'Shop.Theme.Global'),
            'url' => $this->context->link->getPageLink('index', true),
        );

        $breadcrumb['links'][] = array(
            'title' => $this->getTranslator()->trans('Objednávka', array(), 'Shop.Theme.Global'),
            'url' => $this->context->link->getPageLink('order', true),
        );

        return $breadcrumb;
    }

    public function getTemplateVarPage() {
        $templateVarPage = parent::getTemplateVarPage();

        $templateVarPage['meta']['title'] = 'Chyba pri platbe' . ' - '. $templateVarPage['meta']['title'];

        return $templateVarPage;
    }
}