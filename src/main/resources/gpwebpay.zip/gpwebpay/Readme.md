# GP WebPay - Module for accepting payments by credit and debit cards by MasterCard, VISA, Diners Club or American Express credit and debit card, or MasterPass and MasterCard Mobile digital wallet.
# GP WebPay website - www.gpwebpay.cz

