<?php

/*
* PrestaShop - Open Source eCommerce Solution
* @link:                www.prestashop.com
*
* @script name:         PrestaShop GP WebPay
* @purpose:             Module for accepting payments by credit and debit cards by MasterCard, VISA, 
*                       Diners Club or American Express credit and debit card, or MasterPass and MasterCard Mobile digital wallet.
* @type:                Payment module
* @author:              prestashop
* @copyright:           (c) 2001-2018 Prestashop
***************************************
*
* THIS IS COPYRIGHTED SOFTWARE
* PLEASE READ THE LICENSE AGREEMENT
* INCLUDED IN THE DISTRIBUTION PACKAGE
*
***************************************
*
*/

if (!defined('_PS_VERSION_')) {
    exit;
}

class CSignature extends ObjectModel
{
    var $privatni, $heslo, $verejny;

    // CSignature function for PHP 7 +
    function __construct($privatni, $heslo, $verejny)
    {
        $this->privatni = $privatni;
        $this->verejny = $verejny;
        $this->heslo = $heslo;
    }

    function CSignature() 
    {
        self::__construct();
    }

    function sign($text)
    {
        $pkeyid = openssl_get_privatekey($this->privatni, $this->heslo);

        openssl_sign($text, $signature, $pkeyid);
        $signature = base64_encode($signature);
        openssl_free_key($pkeyid);

        return $signature;
    }

    function verify($text, $signature)
    {
        $pubkeyid = openssl_get_publickey($this->verejny);
        $signature = base64_decode($signature);
        $vysledek = openssl_verify($text, $signature, $pubkeyid);
        openssl_free_key($pubkeyid);

        return (($vysledek == 1) ? true : false);
    }
}