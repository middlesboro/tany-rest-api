<?php

/*
* PrestaShop - Open Source eCommerce Solution
* @link:                www.prestashop.com
*
* @script name:         PrestaShop GP WebPay
* @purpose:             Module for accepting payments by credit and debit cards by MasterCard, VISA, 
*                       Diners Club or American Express credit and debit card, or MasterPass and MasterCard Mobile digital wallet.
* @type:                Payment module
* @author:              prestashop
* @copyright:           (c) 2001-2018 Prestashop
***************************************
*
* THIS IS COPYRIGHTED SOFTWARE
* PLEASE READ THE LICENSE AGREEMENT
* INCLUDED IN THE DISTRIBUTION PACKAGE
*
***************************************
*
*/

use PrestaShop\PrestaShop\Core\Payment\PaymentOption;

if (!defined('_PS_VERSION_')) {
    exit;
}

/* Upravena trieda CSignature je dodavana s popisom implementacie GP WebPay */
include_once _PS_MODULE_DIR_.'gpwebpay/classes/CSignature.php';
require_once dirname(__FILE__).'/keys/gpwebpay_public_keys.php';

class Gpwebpay extends PaymentModule
{
    protected $_html = '';
    protected $_postErrors = array();

    public $DEBUG;
    public $gp_public_key;
    public $gp_public_key_test;
    public $gp_product_template;
    public $gp_version;
    public $gp_currency; 
    public $gp_merchantnumber;
    public $gp_password;
    public $gp_bank;
    public $gp_live_flag;
    public $gp_depositflag;
    public $gp_private_key;
    public $gp_private_key_test;
    public $gp_allow_currency_2;
    public $gp_currency_2;
    public $gp_merchantnumber_2;
    public $gp_password_2;
    public $gp_bank_2;
    public $gp_live_flag_2;
    public $gp_depositflag_2;
    public $gp_private_key_2;
    public $gp_private_key_test_2;
    public $gp_allow_currency_3;
    public $gp_currency_3;
    public $gp_merchantnumber_3;
    public $gp_password_3;
    public $gp_bank_3;
    public $gp_live_flag_3;
    public $gp_depositflag_3;
    public $gp_private_key_3;
    public $gp_private_key_test_3;
    public $gp_allow_other_currencies;
    public $gp_icon;
    public $gp_cardicon;
//  public $gp_os_awaiting;
    public $CMS_ID;

    public $ORDER_METHOD; 

    /* All statuses (incl. PrestaShop statuses) */
    public $STATUS_AWAITING; 
    public $STATUS_OK; 
    public $STATUS_FAIL; 

    /* Module statuses only */
    public $OS_AWAITING; // Awaiting for GP WebPay payment

//  public $gp_os_status;

    public $_bank = array();
    public $dir = '';

    public $heslo;
    public $verejny;

    public $currency_codes;
    public $convertedCurrency = false;
    public $convertedConversionRate = null;
    public $extraCurrency = null;
    
    public function __construct()
    {
        $this->name = 'gpwebpay';
        $this->tab = 'payments_gateways';
        $this->version = '1.3'; /* 13.06.2018 */
        $this->ps_versions_compliancy = array('min' => '1.7.0.0', 'max' => _PS_VERSION_);
        $this->author = 'PRESTASHOP';
        $this->controllers = array('payment', 'validation', 'response');

        $this->need_instance = 1;
        $this->currencies = true;        

        $config = Configuration::getMultiple(array('GPWEBPAY_DEBUG', 
                                                    'GPWEBPAY_PUBLIC_KEY', 
                                                    'GPWEBPAY_PUBLIC_KEY_TEST', 
                                                    'GPWEBPAY_VERSION', 
                                                    'GPWEBPAY_CURRENCY', 
                                                    'GPWEBPAY_MERCHANTNUMBER', 
                                                    'GPWEBPAY_PASSWORD', 
                                                    'GPWEBPAY_BANK', 
                                                    'GPWEBPAY_LIVE_FLAG', 
                                                    'GPWEBPAY_DEPOSITFLAG', 
                                                    'GPWEBPAY_PRIVATE_KEY', 
                                                    'GPWEBPAY_PRIVATE_KEY_TEST', 
                                                    'GPWEBPAY_ALLOW_CURRENCY_2', 
                                                    'GPWEBPAY_CURRENCY_2', 
                                                    'GPWEBPAY_MERCHANTNUMBER_2', 
                                                    'GPWEBPAY_PASSWORD_2', 
                                                    'GPWEBPAY_BANK_2', 
                                                    'GPWEBPAY_LIVE_FLAG_2', 
                                                    'GPWEBPAY_DEPOSITFLAG_2', 
                                                    'GPWEBPAY_PRIVATE_KEY_2', 
                                                    'GPWEBPAY_PRIVATE_KEY_TEST_2', 
                                                    'GPWEBPAY_ALLOW_CURRENCY_3', 
                                                    'GPWEBPAY_CURRENCY_3', 
                                                    'GPWEBPAY_MERCHANTNUMBER_3', 
                                                    'GPWEBPAY_PASSWORD_3', 
                                                    'GPWEBPAY_BANK_3', 
                                                    'GPWEBPAY_LIVE_FLAG_3', 
                                                    'GPWEBPAY_DEPOSITFLAG_3', 
                                                    'GPWEBPAY_PRIVATE_KEY_3', 
                                                    'GPWEBPAY_PRIVATE_KEY_TEST_3', 
                                                    'GPWEBPAY_ALLOW_OTHER_CURRENCIES', 
                                                    'GPWEBPAY_ICON', 
                                                    'GPWEBPAY_CARDICON', 
                                                    'GPWEBPAY_CMS_ID',
                                                    'GPWEBPAY_ORDER_METHOD', 
                                                    'GPWEBPAY_STATUS_AWAITING', 
                                                    'GPWEBPAY_STATUS_OK', 
                                                    'GPWEBPAY_STATUS_FAIL', 
                                                    'GPWEBPAY_OS_AWAITING'));

        if (!empty($config['GPWEBPAY_DEBUG'])) {
            $this->DEBUG = $config['GPWEBPAY_DEBUG'];
        }

        if (!empty($config['GPWEBPAY_PUBLIC_KEY'])) {
            $this->gp_public_key = $config['GPWEBPAY_PUBLIC_KEY'];
        }

        if (!empty($config['GPWEBPAY_PUBLIC_KEY_TEST'])) {
            $this->gp_public_key_test = $config['GPWEBPAY_PUBLIC_KEY_TEST'];
        }

        if (!empty($config['GPWEBPAY_VERSION'])) {
            $this->gp_version = $config['GPWEBPAY_VERSION'];
        }

        if (!empty($config['GPWEBPAY_CURRENCY'])) {
            $this->gp_currency = $config['GPWEBPAY_CURRENCY'];
        }

        if (!empty($config['GPWEBPAY_MERCHANTNUMBER'])) {
            $this->gp_merchantnumber = $config['GPWEBPAY_MERCHANTNUMBER'];
        }

        if (!empty($config['GPWEBPAY_PASSWORD'])) {
            $this->gp_password = $config['GPWEBPAY_PASSWORD'];
        }

        if (!empty($config['GPWEBPAY_BANK'])) {
            $this->gp_bank = $config['GPWEBPAY_BANK'];
        }

        if (!empty($config['GPWEBPAY_LIVE_FLAG'])) {
            $this->gp_live_flag = $config['GPWEBPAY_LIVE_FLAG'];
        }

        if (!empty($config['GPWEBPAY_DEPOSITFLAG'])) {
            $this->gp_depositflag = $config['GPWEBPAY_DEPOSITFLAG'];
        }

        if (!empty($config['GPWEBPAY_PRIVATE_KEY'])) {
            $this->gp_private_key = $config['GPWEBPAY_PRIVATE_KEY'];
        }

        if (!empty($config['GPWEBPAY_PRIVATE_KEY_TEST'])) {
            $this->gp_private_key_test = $config['GPWEBPAY_PRIVATE_KEY_TEST'];
        }

        if (!empty($config['GPWEBPAY_ALLOW_CURRENCY_2'])) {
            $this->gp_allow_currency_2 = $config['GPWEBPAY_ALLOW_CURRENCY_2'];    
        }

        if (!empty($config['GPWEBPAY_CURRENCY_2'])) {
            $this->gp_currency_2 = $config['GPWEBPAY_CURRENCY_2'];    
        }

        if (!empty($config['GPWEBPAY_MERCHANTNUMBER_2'])) {
            $this->gp_merchantnumber_2 = $config['GPWEBPAY_MERCHANTNUMBER_2'];    
        }

        if (!empty($config['GPWEBPAY_PASSWORD_2'])) {
            $this->gp_password_2 = $config['GPWEBPAY_PASSWORD_2'];    
        }

        if (!empty($config['GPWEBPAY_BANK_2'])) {
            $this->gp_bank_2 = $config['GPWEBPAY_BANK_2'];    
        }

        if (!empty($config['GPWEBPAY_LIVE_FLAG_2'])) {
            $this->gp_live_flag_2 = $config['GPWEBPAY_LIVE_FLAG_2'];    
        }

        if (!empty($config['GPWEBPAY_DEPOSITFLAG_2'])) {
            $this->gp_depositflag_2 = $config['GPWEBPAY_DEPOSITFLAG_2'];    
        }

        if (!empty($config['GPWEBPAY_PRIVATE_KEY_2'])) {
            $this->gp_private_key_2 = $config['GPWEBPAY_PRIVATE_KEY_2'];
        }

        if (!empty($config['GPWEBPAY_PRIVATE_KEY_TEST_2'])) {
            $this->gp_private_key_test_2 = $config['GPWEBPAY_PRIVATE_KEY_TEST_2'];
        }

        if (!empty($config['GPWEBPAY_ALLOW_CURRENCY_3'])) {
            $this->gp_allow_currency_3 = $config['GPWEBPAY_ALLOW_CURRENCY_3'];    
        }

        if (!empty($config['GPWEBPAY_CURRENCY_3'])) {
            $this->gp_currency_3 = $config['GPWEBPAY_CURRENCY_3'];    
        }

        if (!empty($config['GPWEBPAY_MERCHANTNUMBER_3'])) {
            $this->gp_merchantnumber_3 = $config['GPWEBPAY_MERCHANTNUMBER_3'];    
        }

        if (!empty($config['GPWEBPAY_PASSWORD_3'])) {
            $this->gp_password_3 = $config['GPWEBPAY_PASSWORD_3'];    
        }

        if (!empty($config['GPWEBPAY_BANK_3'])) {
            $this->gp_bank_3 = $config['GPWEBPAY_BANK_3'];    
        }

        if (!empty($config['GPWEBPAY_LIVE_FLAG_3'])) {
            $this->gp_live_flag_3 = $config['GPWEBPAY_LIVE_FLAG_3'];    
        }

        if (!empty($config['GPWEBPAY_DEPOSITFLAG_3'])) {
            $this->gp_depositflag_3 = $config['GPWEBPAY_DEPOSITFLAG_3'];    
        }

        if (!empty($config['GPWEBPAY_PRIVATE_KEY_3'])) {
            $this->gp_private_key_3 = $config['GPWEBPAY_PRIVATE_KEY_3'];
        }

        if (!empty($config['GPWEBPAY_PRIVATE_KEY_TEST_3'])) {
            $this->gp_private_key_test_3 = $config['GPWEBPAY_PRIVATE_KEY_TEST_3'];
        }

        if (!empty($config['GPWEBPAY_ALLOW_OTHER_CURRENCIES'])) {
            $this->gp_allow_other_currencies = $config['GPWEBPAY_ALLOW_OTHER_CURRENCIES'];    
        }

        if (!empty($config['GPWEBPAY_ICON'])) {
            $this->gp_icon = $config['GPWEBPAY_ICON'];    
        }

        if (!empty($config['GPWEBPAY_CARDICON'])) {
            $this->gp_cardicon = $config['GPWEBPAY_CARDICON'];    
        }

        if (!empty($config['GPWEBPAY_CMS_ID'])) {
            $this->CMS_ID = $config['GPWEBPAY_CMS_ID'];
        }

        if (!empty($config['GPWEBPAY_ORDER_METHOD'])) {
            $this->ORDER_METHOD = $config['GPWEBPAY_ORDER_METHOD'];
        }

        /* All statuses (incl. PrestaShop statuses) - Start */
        if (!empty($config['GPWEBPAY_STATUS_AWAITING'])) {
            $this->STATUS_AWAITING = $config['GPWEBPAY_STATUS_AWAITING'];
        }

        if (!empty($config['GPWEBPAY_STATUS_OK'])) {
            $this->STATUS_OK = $config['GPWEBPAY_STATUS_OK'];
        }

        if (!empty($config['GPWEBPAY_STATUS_FAIL'])) {
            $this->STATUS_FAIL = $config['GPWEBPAY_STATUS_FAIL'];
        }
        /* All statuses (incl. PrestaShop statuses) - End */

        /* Module statuses only - Start */
        if (!empty($config['GPWEBPAY_OS_AWAITING'])) {
            $this->OS_AWAITING = $config['GPWEBPAY_OS_AWAITING'];
        }
        /* Module statuses only - End */

        $this->bootstrap = true;
        parent::__construct ();

        $this->displayName = $this->l('GP WebPay');
        $this->description = $this->l('Module for accepting payments by credit and debit cards by MasterCard, VISA, Diners Club or American Express credit and debit card, or MasterPass and MasterCard Mobile digital wallet.');
        $this->confirmUninstall = $this->l('Are you sure you want to uninstall GP WebPay module?');

        /* Warning massages */
        if ($this->DEBUG == '1') {
            $this->warning = $this->l('Debugging mode is allowed. Switch off immediately if module is in the production environment!');
        }

        if (!isset($this->gp_merchantnumber)) {
            $this->warning = $this->l('Your Merchant Number must be configured in order to use this module correctly.');
        }

        if (!isset($this->gp_public_key)) {
            $this->warning = $this->l('Public Key (Live) missing. Please reinstall the module.');
        }

        if (!isset($this->gp_public_key_test)) {
            $this->warning = $this->l('Public Key (Testing) missing. Please reinstall the module.');
        }

        if (!isset($this->gp_private_key)) {
            $this->warning = $this->l('Your Private Key (Live) must be configured in order to use this module correctly.');
        }

        if (!isset($this->gp_private_key_test)) {
            $this->warning = $this->l('Your Private Key (Testing) must be configured in order to use this module correctly.');
        }

        if (!isset($this->gp_currency)) {
            $this->warning = $this->l('Payment currency must be configured in order to use this module correctly.');
        }

        if (!isset($this->gp_password)) {
            $this->warning = $this->l('Private Key password must be configured in order to use this module correctly.');
        }

        if (!isset($this->gp_bank)) {
            $this->warning = $this->l('Bank must be configured in order to use this module correctly.');
        }

        if (!isset($this->gp_live_flag)) {
            $this->warning = $this->l('Working Mode must be configured in order to use this module correctly.');
        }

        if (!isset($this->gp_depositflag)) {
            $this->warning = $this->l('Payment processing Mode must be configured in order to use this module correctly.');
        }

        /* Module statuses only - Start */
        if (!isset($this->OS_AWAITING)) {
            $this->warning = $this->l('The payment order status &quot;Awaiting GP WebPay payment&quot; is not present.');
        }
        /* Module statuses only - End */

        if (self::isInstalled($this->name)) {
            $this->_bank = array(
                    'undefined' => 'about:blank',
                    'KB'        => 'https://3dsecure.gpwebpay.com/kb/order.do',
//                  'CSOB'      => 'https://3dsecure.gpwebpay.com/csob/order.do',
                    'CSOB Sk'   => 'https://3dsecure.gpwebpay.com/csobsk/order.do',
                    'SLSP'      => 'https://3dsecure.gpwebpay.com/pgw/order.do',
                    'CSP'       => 'https://3dsecure.gpwebpay.com/pgw/order.do',
                    'UB'        => 'https://3dsecure.gpwebpay.com/unicredit/order.do',
                    'RB'        => 'https://3dsecure.gpwebpay.com/rb/order.do',
                    'LPB'       => 'https://3dsecure.gpwebpay.com/lpb/order.do',
            );

            $this->currency_codes = array(
                                'EUR' => 978, 
                                'CZK' => 203, 
                                'GBP' => 826, 
                                'USD' => 840,
                                'HUF' => 348,
                                'PLN' => 985,
                                'RUB' => 643,
                                );
        }
    }

    /******** INSTALL ********/
    public function install()
    {
        /* Install SQL */
        $sql = array();

        /* ACTION: SQL query to create [PREFIX]_gpawebpay_log table */
        /* PURPOSE: Table to log GP WebPay payment transactions in the database */
        $sql[] = 'CREATE TABLE IF NOT EXISTS `'._DB_PREFIX_.'gpwebpay_log` (
            `id` int(11) NOT NULL auto_increment,
            `customer_id` int(11) NOT NULL,
            `shop_id` int(11) NOT NULL,
            `order_id` int(11) NOT NULL,
            `merchant_id` varchar(12) NOT NULL,
            `ORDERNUMBER` varchar(16) NOT NULL,
            `total` varchar(12) NOT NULL,
            `CURRENCY` varchar(3) NOT NULL,
            `DEPOSITFLAG` varchar(1) NOT NULL,
            `return_url` varchar(255) NOT NULL,
            `description` varchar(255) NOT NULL,
            `MD` varchar(255) NOT NULL,
            `date_create` datetime NOT NULL,
            `PRCODE` int(11) NOT NULL,
            `SRCODE` int(11) NOT NULL,
            `RESULTTEXT` varchar(255) NOT NULL,
            `DIGEST` text NOT NULL,
            `DIGEST1` text NOT NULL,
            `SESSION_BUTTON` text NOT NULL,
            `payment_start` text NOT NULL,
            `payment_end` text NOT NULL,
            `timestamp` datetime NOT NULL,
            PRIMARY KEY (`id`),
            KEY `customer_id` (`customer_id`,`date_create`,`timestamp`)
        ) ENGINE='._MYSQL_ENGINE_.' DEFAULT CHARSET=utf8 COMMENT="Transakcie GP WebPay";';

        foreach ($sql as $s) {
            if (!Db::getInstance()->Execute($s)) {
                return false;
            }
        }

        /* Install Module */
        if (!parent::install() 
            || !$this->registerHook('paymentOptions') 
            || !$this->registerHook('paymentReturn') 
            || !$this->registerHook('leftColumn')
            || !$this->registerHook('rightColumn') 
            || !$this->registerHook('displayProductButtons')
            || !$this->registerHook('displayHeader')) {
        return false;
        }

        /* Initial settings */
        /* Public Keys stored in DB - TO-DO */
        Configuration::updateValue('GPWEBPAY_PUBLIC_KEY', '-----BEGIN CERTIFICATE-----
MIIDFjCCAf4CCQCQ12pToLHiljANBgkqhkiG9w0BAQUFADBNMRgwFgYDVQQDEw9N
ZXNzYWdlIFNpZ25pbmcxEDAOBgNVBAsTB1BheU1VWk8xEjAQBgNVBAoTCU1VWk8s
YS5zLjELMAkGA1UEBhMCQ1owHhcNMTMwODAxMTI1NzMyWhcNMzMwNzI3MTI1NzMy
WjBNMRgwFgYDVQQDEw9NZXNzYWdlIFNpZ25pbmcxEDAOBgNVBAsTB1BheU1VWk8x
EjAQBgNVBAoTCU1VWk8sYS5zLjELMAkGA1UEBhMCQ1owggEiMA0GCSqGSIb3DQEB
AQUAA4IBDwAwggEKAoIBAQDimVN4A77p26u2yx6x+gC9nQ4bVqEuTk6Qj18EKPft
ws2WhZavsQIZPK6Xq3mVkM5teTdn0To1EA2jr5gySkTeBPWEKTn3pqrcx1hgri/J
9MnXv+csD5ThAgW/IZKpfETxZqzF+1biX1/4tjWDOFi7VPrl1E+M5BTd8CSZn6ix
fSDrm2YLPIz5UbWk5GmqYH9u7kXLXx4oEhiWZkPVpjVoFm4b36Dof2UBXOECjRb1
brmchTa1mfsvb8e0PbtxkRZUsf+/K3IG12E01qSdDIynBfK/dYpOq23tb0mREwpj
/NtrfoOX4YWjkF/PQjEA2Yl8FhVpYK2efvGJUGhv/gx1AgMBAAEwDQYJKoZIhvcN
AQEFBQADggEBAJtyJ7EhIH2Xz36plp1WWBh0TNT1mxjZlGVnX7w7LiZo+WHoHONd
oZwAMESmx5nGqfNujHxjo4X3Cfbp5CWYiowlAd9U3E6eI3oDkJhx+sAgcTxMcpta
frSCiM2EXK+fSdwGNhI3hurcy/DXh8kSBFwNSEuFkpusemW/GOQJ7czesEkz9ASh
sU78Kg7BrtKCMXXyTGyIHyB+TXB+wpwx7XMk2LHFPMXi7GYP+4ymVM3976k4HL0r
h3I5/FT3AGsLLc1Mu25vsNsmqtBuVhP8CowJs59+24Cp0S8sx+mRGyYTkv7FDP6y
nLh6hcua1RwpWF60biU9/ZiJ4oojfsGFLjs=
-----END CERTIFICATE-----');
        Configuration::updateValue('GPWEBPAY_PUBLIC_KEY_TEST', '-----BEGIN PUBLIC KEY-----
MIIBIjANBgkqhkiG9w0BAQEFAAOCAQ8AMIIBCgKCAQEAukooJBqkgau4pjhxkDC3
5hDl0SHOn3BonEU1ldz/l6886nJhypHNkLSHgBJRvhbLz/QdOD3mZShrupcxNRKT
cA1oLzWWWOeLlgmK0cSM5Xchy/vE6LVbij4+wKtujfPZWg4XIdJFpb4VBTj0mx3N
X5nKshu2A987uIZGYB6YapS3NGWPSJL5VPwdv5PRqV4U0v4/DuQl01A9v8fuqr3b
s+AsqUXzWfLALHLnxxoCzaEzUC+EV2b7jcNyngjv9vDhOeGsxrojQA73w2Lf16Bu
aSQrlIUWDt4BAhIc+L8ZM8pKGXtbwXP1NwBtxQ2FvtAqfHqwHdw4yrb/V2Q/QMaB
8wIDAQAB
-----END PUBLIC KEY-----');

        Configuration::updateValue('GPWEBPAY_DEBUG', '1');
        Configuration::updateValue('GPWEBPAY_VERSION', $this->version);

        Configuration::updateValue('GPWEBPAY_CURRENCY','EUR');
        Configuration::updateValue('GPWEBPAY_BANK', 'undefined');
        Configuration::updateValue('GPWEBPAY_LIVE_FLAG', '0');
        Configuration::updateValue('GPWEBPAY_DEPOSITFLAG', '1');

        Configuration::updateValue('GPWEBPAY_ALLOW_CURRENCY_2','0');
        Configuration::updateValue('GPWEBPAY_ALLOW_CURRENCY_3','0');
        Configuration::updateValue('GPWEBPAY_ALLOW_OTHER_CURRENCIES','0');

        Configuration::updateValue('GPWEBPAY_ICON', 'p');
        Configuration::updateValue('GPWEBPAY_CARDICON', '1');
        Configuration::updateValue('GPWEBPAY_CMS_ID', '3');

        Configuration::updateValue('GPWEBPAY_ORDER_METHOD', 'before');

        /* PrestaShop built-in statuses only */
        Configuration::updateValue('GPWEBPAY_STATUS_OK', '2');
        Configuration::updateValue('GPWEBPAY_STATUS_FAIL', '8');

        /* Copy e-mail templates */
        $this->moveOverriteFiles();

        /* Create a new OrderState */
        if (!Configuration::get('GPWEBPAY_OS_AWAITING')) {
            $orderState = new OrderState();
            $orderState->name = array();
            foreach (Language::getLanguages() as $language) {
                if (strtolower($language['iso_code']) == 'sk') {
                    $orderState->name[$language['id_lang']] = 'Čakanie na platbu GP WebPay';
                } elseif (strtolower($language['iso_code']) == 'cs') {
                    $orderState->name[$language['id_lang']] = 'Čekání na platbu GP WebPay';
                } elseif (strtolower($language['iso_code']) == 'en') {
                    $orderState->name[$language['id_lang']] = 'Awaiting GP WebPay payment';
                } else {
                    $orderState->name[$language['id_lang']] = 'Awaiting GP WebPay payment';
                }
            }
            $orderState->send_email = false;

            $orderState->template = array();
            foreach (Language::getLanguages() as $language) {
                $orderState->template[$language['id_lang']] = 'gpwebpay_awaiting';
            }

            $orderState->color = '#4169E1';
            $orderState->hidden = false;
            $orderState->delivery = false;
            $orderState->logable = false;
            $orderState->module_name = $this->name;
            $orderState->invoice = false;
            if ($orderState->add()) {
                copy(dirname(__FILE__).'/views/img/os/'.$this->name.'-awaiting.gif', dirname(__FILE__).'/../../img/os/'.(int)$orderState->id.'.gif');
            }
            Configuration::updateValue('GPWEBPAY_OS_AWAITING', (int)$orderState->id);
        }

         /* Module statuses only - Start */
        Configuration::updateValue('GPWEBPAY_STATUS_AWAITING', Configuration::get('GPWEBPAY_OS_AWAITING'));
        /* Module statuses only - End */

        $whitelist = array('127.0.0.1', '::1');
        if (!in_array($_SERVER['REMOTE_ADDR'], $whitelist)) {
            $this->_notifyMe();
        }

        return true;
    }

    /******** UNINSTALL ********/
    public function uninstall()
    {
/*
        $orderState = new OrderState((int)(Configuration::get('GPWEBPAY_STATUS_AWAITING')), Configuration::get('PS_LANG_DEFAULT'));
        if (!$orderState->delete()) {
            return false;
        }
*/
        /* Delete DB table */
        $sql = array();
        foreach ($sql as $s) {
            if (!Db::getInstance()->Execute($s)) {
                return false;
            }
        }

        if (!$this->unregisterHook('paymentOptions') 
                || !$this->unregisterHook('paymentReturn') 
                || !$this->unregisterHook('leftColumn') 
                || !$this->unregisterHook('rightColumn') 
                || !$this->unregisterHook('displayProductButtons') 
                || !$this->unregisterHook('displayHeader') 
                || !Configuration::deleteByName('GPWEBPAY_VERSION') 
                || !Configuration::deleteByName('GPWEBPAY_DEBUG') 
                || !Configuration::deleteByName('GPWEBPAY_PUBLIC_KEY')  
                || !Configuration::deleteByName('GPWEBPAY_PUBLIC_KEY_TEST') 
                || !Configuration::deleteByName('GPWEBPAY_CURRENCY') 
                || !Configuration::deleteByName('GPWEBPAY_MERCHANTNUMBER') 
                || !Configuration::deleteByName('GPWEBPAY_PASSWORD') 
                || !Configuration::deleteByName('GPWEBPAY_BANK') 
                || !Configuration::deleteByName('GPWEBPAY_LIVE_FLAG') 
                || !Configuration::deleteByName('GPWEBPAY_DEPOSITFLAG') 
                || !Configuration::deleteByName('GPWEBPAY_PRIVATE_KEY') 
                || !Configuration::deleteByName('GPWEBPAY_PRIVATE_KEY_TEST') 
                || !Configuration::deleteByName('GPWEBPAY_ALLOW_CURRENCY_2') 
                || !Configuration::deleteByName('GPWEBPAY_CURRENCY_2') 
                || !Configuration::deleteByName('GPWEBPAY_MERCHANTNUMBER_2') 
                || !Configuration::deleteByName('GPWEBPAY_PASSWORD_2') 
                || !Configuration::deleteByName('GPWEBPAY_BANK_2') 
                || !Configuration::deleteByName('GPWEBPAY_LIVE_FLAG_2') 
                || !Configuration::deleteByName('GPWEBPAY_DEPOSITFLAG_2') 
                || !Configuration::deleteByName('GPWEBPAY_PRIVATE_KEY_2') 
                || !Configuration::deleteByName('GPWEBPAY_PRIVATE_KEY_TEST_2') 
                || !Configuration::deleteByName('GPWEBPAY_ALLOW_CURRENCY_3') 
                || !Configuration::deleteByName('GPWEBPAY_CURRENCY_3') 
                || !Configuration::deleteByName('GPWEBPAY_MERCHANTNUMBER_3') 
                || !Configuration::deleteByName('GPWEBPAY_PASSWORD_3') 
                || !Configuration::deleteByName('GPWEBPAY_BANK_3') 
                || !Configuration::deleteByName('GPWEBPAY_LIVE_FLAG_3') 
                || !Configuration::deleteByName('GPWEBPAY_DEPOSITFLAG_3') 
                || !Configuration::deleteByName('GPWEBPAY_PRIVATE_KEY_3') 
                || !Configuration::deleteByName('GPWEBPAY_PRIVATE_KEY_TEST_3') 
                || !Configuration::deleteByName('GPWEBPAY_ALLOW_OTHER_CURRENCIES') 
                || !Configuration::deleteByName('GPWEBPAY_ICON') 
                || !Configuration::deleteByName('GPWEBPAY_CARDICON') 
                || !Configuration::deleteByName('GPWEBPAY_CMS_ID') 
                || !Configuration::deleteByName('GPWEBPAY_ORDER_METHOD')
//              || !Configuration::deleteByName('GPWEBPAY_STATUS_AWAITING')
                || !Configuration::deleteByName('GPWEBPAY_STATUS_OK')
                || !Configuration::deleteByName('GPWEBPAY_STATUS_FAIL')
//              || !Configuration::deleteByName('GPWEBPAY_OS_AWAITING')
                || !parent::uninstall()) {
            return false;
        }
        return true;
    }

    /******** COPY E-MAIL TEMPLATES INTO /mails/ FOLDER ********/
    private function moveOverriteFiles()
    {
        foreach (Language::getLanguages() as $language) {
            if (strtolower($language['iso_code']) == 'sk') {

                if (!copy(dirname(__FILE__).'/mails/sk/'.$this->name.'_awaiting.html',_PS_ROOT_DIR_ .'/mails/sk/'.$this->name.'_awaiting.html')
                        || !copy(dirname(__FILE__).'/mails/sk/'.$this->name.'_awaiting.txt',_PS_ROOT_DIR_ .'/mails/sk/'.$this->name.'_awaiting.txt')) {
                    return false;
                }

            } elseif (strtolower($language['iso_code']) == 'cs') {

                if (!copy(dirname(__FILE__).'/mails/cs/'.$this->name.'_awaiting.html',_PS_ROOT_DIR_ .'/mails/cs/'.$this->name.'_awaiting.html')
                        || !copy(dirname(__FILE__).'/mails/cs/'.$this->name.'_awaiting.txt',_PS_ROOT_DIR_ .'/mails/cs/'.$this->name.'_awaiting.txt')) {
                    return false;
                }

            } elseif (strtolower($language['iso_code']) == 'en') {

                if (!copy(dirname(__FILE__).'/mails/en/'.$this->name.'_awaiting.html',_PS_ROOT_DIR_ .'/mails/en/'.$this->name.'_awaiting.html')
                        || !copy(dirname(__FILE__).'/mails/en/'.$this->name.'_awaiting.txt',_PS_ROOT_DIR_ .'/mails/en/'.$this->name.'_awaiting.txt')) {
                    return false;
                }

            } else {

                if (!copy(dirname(__FILE__).'/mails/en/'.$this->name.'_awaiting.html',_PS_ROOT_DIR_ .'/mails/en/'.$this->name.'_awaiting.html')
                        || !copy(dirname(__FILE__).'/mails/en/'.$this->name.'_awaiting.txt',_PS_ROOT_DIR_ .'/mails/en/'.$this->name.'_awaiting.txt')) {
                    return false;
                }

            }
        }

        return true;
    }

    /******** POST VALIDATION ********/
    protected function _postValidation()
    {
        if (Tools::isSubmit('btnSubmitCurrency1')) {

            if (!Tools::getValue('GPWEBPAY_CURRENCY')) {
                $this->_postErrors[] = $this->l('Payment currency is required.');
            } elseif (!Tools::getValue('GPWEBPAY_MERCHANTNUMBER')) {
                $this->_postErrors[] = $this->l('Merchant number is required.');
  //        } elseif (!Tools::getValue('GPWEBPAY_PRIVATE_KEY')) {
  //            $this->_postErrors[] = $this->l('Private Key is required.');
            } elseif (!Tools::getValue('GPWEBPAY_PASSWORD')) {
                $this->_postErrors[] = $this->l('Private key password is required.');
            } elseif (!Tools::getValue('GPWEBPAY_BANK')) {
                $this->_postErrors[] = $this->l('Please choose your bank.');
            }

        } elseif (Tools::isSubmit('btnSubmitCurrency2')) {

            if (Configuration::get('GPWEBPAY_ALLOW_CURRENCY_2') == '1') {

                if (!Tools::getValue('GPWEBPAY_CURRENCY_2')) {
                $this->_postErrors[] = $this->l('Payment currency is required.');
                } elseif (!Tools::getValue('GPWEBPAY_MERCHANTNUMBER_2')) {
                $this->_postErrors[] = $this->l('Merchant Number is required.');
                } elseif (!Tools::getValue('GPWEBPAY_PASSWORD_2')) {
                $this->_postErrors[] = $this->l('Private key password is required.');
                } elseif (!Tools::getValue('GPWEBPAY_BANK_2')) {
                $this->_postErrors[] = $this->l('Please choose your bank.');
                }
            }

        } elseif (Tools::isSubmit('btnSubmitCurrency3')) {
        
            if (Configuration::get('GPWEBPAY_ALLOW_CURRENCY_3') == '1') {

                if (!Tools::getValue('GPWEBPAY_CURRENCY_3')) {
                $this->_postErrors[] = $this->l('Payment currency is required.');
                } elseif (!Tools::getValue('GPWEBPAY_MERCHANTNUMBER_3')) {
                $this->_postErrors[] = $this->l('Merchant Number is required.');
                } elseif (!Tools::getValue('GPWEBPAY_PASSWORD_3')) {
                $this->_postErrors[] = $this->l('Private key password is required.');
                } elseif (!Tools::getValue('GPWEBPAY_BANK_3')) {
                $this->_postErrors[] = $this->l('Please choose your bank.');
                }
            }
        } elseif (Tools::isSubmit('btnSubmitOrder')) {
            if (!Tools::getValue('GPWEBPAY_ORDER_METHOD')) {
                $this->_postErrors[] = $this->l('Choose one of the order method.');
            } elseif (!Tools::getValue('GPWEBPAY_STATUS_AWAITING')) {
                $this->_postErrors[] = $this->l('Awaiting payment order status is required.');
            } elseif (!Tools::getValue('GPWEBPAY_STATUS_OK')) {
                $this->_postErrors[] = $this->l('Success order status is required.');
            } elseif (!Tools::getValue('GPWEBPAY_STATUS_FAIL')) {
                $this->_postErrors[] = $this->l('Error order status is required.');
            }
        }
    }

    /******** POST PROCESS ********/
    protected function _postProcess()
    {
        if (Tools::isSubmit('btnSubmitCurrency1')) {
            Configuration::updateValue('GPWEBPAY_DEBUG', Tools::getValue('GPWEBPAY_DEBUG'));
            Configuration::updateValue('GPWEBPAY_CURRENCY', Tools::getValue('GPWEBPAY_CURRENCY'));
            Configuration::updateValue('GPWEBPAY_MERCHANTNUMBER', 0+Tools::getValue('GPWEBPAY_MERCHANTNUMBER'));
            Configuration::updateValue('GPWEBPAY_PASSWORD', Tools::getValue('GPWEBPAY_PASSWORD'));
            Configuration::updateValue('GPWEBPAY_BANK', Tools::getValue('GPWEBPAY_BANK'));
            Configuration::updateValue('GPWEBPAY_LIVE_FLAG', Tools::getValue('GPWEBPAY_LIVE_FLAG'));
            Configuration::updateValue('GPWEBPAY_DEPOSITFLAG', Tools::getValue('GPWEBPAY_DEPOSITFLAG'));
            Configuration::updateValue('GPWEBPAY_PRIVATE_KEY', Tools::getValue('GPWEBPAY_PRIVATE_KEY'));
            Configuration::updateValue('GPWEBPAY_PRIVATE_KEY_TEST', Tools::getValue('GPWEBPAY_PRIVATE_KEY_TEST'));
            $this->_html .= $this->displayConfirmation($this->l('Main module settings updated successfuly'));

        } elseif (Tools::isSubmit('btnSubmitCurrency2')) {

            Configuration::updateValue('GPWEBPAY_ALLOW_CURRENCY_2', Tools::getValue('GPWEBPAY_ALLOW_CURRENCY_2'));
            Configuration::updateValue('GPWEBPAY_CURRENCY_2', Tools::getValue('GPWEBPAY_CURRENCY_2'));
            Configuration::updateValue('GPWEBPAY_MERCHANTNUMBER_2', Tools::getValue('GPWEBPAY_MERCHANTNUMBER_2'));
            Configuration::updateValue('GPWEBPAY_PASSWORD_2', Tools::getValue('GPWEBPAY_PASSWORD_2'));
            Configuration::updateValue('GPWEBPAY_BANK_2', Tools::getValue('GPWEBPAY_BANK_2'));
            Configuration::updateValue('GPWEBPAY_LIVE_FLAG_2', Tools::getValue('GPWEBPAY_LIVE_FLAG_2'));
            Configuration::updateValue('GPWEBPAY_DEPOSITFLAG_2', Tools::getValue('GPWEBPAY_DEPOSITFLAG_2'));
            Configuration::updateValue('GPWEBPAY_PRIVATE_KEY_2', Tools::getValue('GPWEBPAY_PRIVATE_KEY_2'));
            Configuration::updateValue('GPWEBPAY_PRIVATE_KEY_TEST_2', Tools::getValue('GPWEBPAY_PRIVATE_KEY_TEST_2'));
            $this->_html .= $this->displayConfirmation($this->l('Module settings for second currency updated successfuly'));

        } elseif (Tools::isSubmit('btnSubmitCurrency3')) {

            Configuration::updateValue('GPWEBPAY_ALLOW_CURRENCY_3', Tools::getValue('GPWEBPAY_ALLOW_CURRENCY_3'));
            Configuration::updateValue('GPWEBPAY_CURRENCY_3', Tools::getValue('GPWEBPAY_CURRENCY_3'));
            Configuration::updateValue('GPWEBPAY_MERCHANTNUMBER_3', Tools::getValue('GPWEBPAY_MERCHANTNUMBER_3'));
            Configuration::updateValue('GPWEBPAY_PASSWORD_3', Tools::getValue('GPWEBPAY_PASSWORD_3'));
            Configuration::updateValue('GPWEBPAY_BANK_3', Tools::getValue('GPWEBPAY_BANK_3'));
            Configuration::updateValue('GPWEBPAY_LIVE_FLAG_3', Tools::getValue('GPWEBPAY_LIVE_FLAG_3'));
            Configuration::updateValue('GPWEBPAY_DEPOSITFLAG_3', Tools::getValue('GPWEBPAY_DEPOSITFLAG_3'));
            Configuration::updateValue('GPWEBPAY_PRIVATE_KEY_3', Tools::getValue('GPWEBPAY_PRIVATE_KEY_3'));
            Configuration::updateValue('GPWEBPAY_PRIVATE_KEY_TEST_3', Tools::getValue('GPWEBPAY_PRIVATE_KEY_TEST_3'));
            $this->_html .= $this->displayConfirmation($this->l('Module settings for third currency updated successfuly'));

        } elseif (Tools::isSubmit('btnSubmitOtherCurrency')) {

            Configuration::updateValue('GPWEBPAY_ALLOW_OTHER_CURRENCIES', Tools::getValue('GPWEBPAY_ALLOW_OTHER_CURRENCIES'));
            $this->_html .= $this->displayConfirmation($this->l('Module settings for other currencies updated successfuly'));

        } elseif (Tools::isSubmit('btnSubmitOrder')) {

            Configuration::updateValue('GPWEBPAY_ORDER_METHOD', Tools::getValue('GPWEBPAY_ORDER_METHOD'));
            Configuration::updateValue('GPWEBPAY_STATUS_AWAITING', Tools::getValue('GPWEBPAY_STATUS_AWAITING'));
            Configuration::updateValue('GPWEBPAY_STATUS_OK', Tools::getValue('GPWEBPAY_STATUS_OK'));
            Configuration::updateValue('GPWEBPAY_STATUS_FAIL', Tools::getValue('GPWEBPAY_STATUS_FAIL'));
            $this->_html .= $this->displayConfirmation($this->l('The order settings updated successfuly'));

        } elseif (Tools::isSubmit('btnSubmitIcon')) {

            Configuration::updateValue('GPWEBPAY_ICON', Tools::getValue('GPWEBPAY_ICON'));
            Configuration::updateValue('GPWEBPAY_CARDICON', Tools::getValue('GPWEBPAY_CARDICON'));
            Configuration::updateValue('GPWEBPAY_CMS_ID', Tools::getValue('GPWEBPAY_CMS_ID'));
            $this->_html .= $this->displayConfirmation($this->l('Icon settings updated successfuly'));
        }
    }

    /******** MODULE INFOS ********/
    private function _displayInfos()
    {
        $this->smarty->assign(array(
            'module_name' => $this->displayName,
            'module_desc' => $this->description,
            'module_version' => $this->version,
            'module_logo' => Media::getMediaPath(_PS_MODULE_DIR_.$this->name.'/views/img/'.$this->name.'-logo.png'),
        ));

        return $this->display(__FILE__, 'mod_infos.tpl');
    }
    
    /******** MODULE CREDIT ********/
    private function _displayCredit()
    {
        $this->smarty->assign(array(
            'module_changelog' => Media::getMediaPath(_PS_MODULE_DIR_.$this->name.'/CHANGELOG.txt'),
            'module_readme' => Media::getMediaPath(_PS_MODULE_DIR_.$this->name.'/docs/readme-'.$this->name.'.html'),
            'module_license' => Media::getMediaPath(_PS_MODULE_DIR_.$this->name.'/docs/terms-and-conditions-of-use.pdf'),
        ));

        return $this->display(__FILE__, 'mod_credit.tpl');
    }

    /******** MODULE ALERTS ********/
    private function _displayAlert()
    {
        if (!extension_loaded('openssl')) {
            $alert_ssl = 'yes';
        } else {
            $alert_ssl = 'no';
        }
        
        $this->smarty->assign(array(
            'alert_ssl' => $alert_ssl,
        ));

    return $this->display(__FILE__, 'mod_alert.tpl');
    }

    /******** ENCRYPTION KEYS ********/
    public function keys($id_currency = null) 
    {
        if (empty($id_currency)) {
            die('$id_currency je prazdne, stop.');
        }

        $curr = new Currency(intval($id_currency));

        if ($curr->iso_code_num == $this->currency_codes[Configuration::get('GPWEBPAY_CURRENCY')]) {
            $CURRENCY = $curr->iso_code_num;
            $this->extraCurrency = '';
        } elseif (Configuration::get('GPWEBPAY_ALLOW_CURRENCY_2') && $curr->iso_code_num == $this->currency_codes[Configuration::get('GPWEBPAY_CURRENCY_2')]) {
            $CURRENCY = $curr->iso_code_num;
            $this->extraCurrency = '_2';
        } elseif (Configuration::get('GPWEBPAY_ALLOW_CURRENCY_3') && $curr->iso_code_num == $this->currency_codes[Configuration::get('GPWEBPAY_CURRENCY_3')]) {
            $CURRENCY = $curr->iso_code_num;
            $this->extraCurrency = '_3';
        } elseif (Configuration::get('GPWEBPAY_ALLOW_OTHER_CURRENCIES')) {
            $this->convertedCurrency = $curr->sign;
            $this->convertedConversionRate = $curr->conversion_rate;
            $CURRENCY = $this->currency_codes[Configuration::get('GPWEBPAY_CURRENCY')];
            $this->extraCurrency = '';
        } else {
            $this->currency_alert = $this->l('GP WebPay not support chosen payment currency. Please choose another.');
//          echo $this->l('GP WebPay not support chosen payment currency. Please choose another.');
            return;
        }

        if (defined('GPWEBPAY_MODULE')) {
            return $CURRENCY;
        } else {
            define('GPWEBPAY_MODULE', true);
            $keys = array();
            require_once dirname(__FILE__).'/keys/gpwebpay_public_keys.php';
        }

        if (Configuration::get('GPWEBPAY_LIVE_FLAG'.$this->extraCurrency)) {
            $test = '';
            $this->verejny = GPWEBPAY_CERT_PUBLIC;
        } else {
            $test = '_TEST';
            $this->verejny = GPWEBPAY_CERT_PUBLIC_TEST;
        }

        $this->heslo = Configuration::get('GPWEBPAY_PASSWORD'.$this->extraCurrency);

        return $CURRENCY;
    }

    /******** PAYMENT RETURN ********/
    public function hookPaymentReturn($params)
    {
        if (!$this->active)
            return;

        $this->smarty->assign('reference', $params['order']->reference);

        $theme_name = apPageHelper::getThemeName();
        $templatePath = _PS_ALL_THEMES_DIR_.$theme_name.'/templates/checkout/order-confirmation-payment-common.tpl';

        return $this->fetch($templatePath);
    }

    /******** PAYMENT RECORDS LISTING ********/
    public function _displayRecords()
    {
            $this->smarty->assign(array(
                'records' => Db::getInstance()->ExecuteS('SELECT * FROM '._DB_PREFIX_.'gpwebpay_log ORDER BY id DESC LIMIT 50'),
                'customer_link' => $this->context->link->getAdminLink('AdminCustomers'),
                'shopping_cart' => $this->context->link->getAdminLink('AdminCarts'),
                'order' => $this->context->link->getAdminLink('AdminOrders'),
                ));

        return $this->display(__FILE__, 'mod_records.tpl');
    }

    /******** GET CONTENT ********/
    public function getContent()
    {
        $this->_html = '';

        $this->_html .= $this->_displayInfos();
        $this->_html .= $this->_displayAlert();
        $this->_html .= $this->_displayRecords();

        if (Tools::isSubmit('btnSubmitCurrency1') 
                    || Tools::isSubmit('btnSubmitCurrency2') 
                    || Tools::isSubmit('btnSubmitCurrency3') 
                    || Tools::isSubmit('btnSubmitOtherCurrency') 
                    || Tools::isSubmit('btnSubmitOrder') 
                    || Tools::isSubmit('btnSubmitIcon')) {
            $this->_postValidation();
            if (!count($this->_postErrors)) {
                $this->_postProcess();
            } else {
                foreach ($this->_postErrors as $err) {
                    $this->_html .= $this->displayError($err);
                }
            }
        } else {
            $this->_html .= '';
        }

        $this->_html .= $this->renderFormCurrency1();
        $this->_html .= $this->renderFormCurrency2();
        $this->_html .= $this->renderFormCurrency3();
        $this->_html .= $this->renderFormCurrencyOther();
        $this->_html .= $this->renderFormOrder();
        $this->_html .= $this->renderFormIcon();
        $this->_html .= $this->_displayCredit();

        return $this->_html;
    }

    /******** PAYMENT OPTIONS ********/
    public function hookPaymentOptions($params)
    {
        if (!$this->active) {
            return;
        }
/*
        if (!$this->checkCurrency($params['cart'])) {
            return;
        }
*/
        $this->context->smarty->assign(
            $this->getTemplateVarInfos()
        );

        $newOption = new PaymentOption();
        $newOption->setModuleName($this->name);
        $newOption->setCallToActionText($this->l('GP WebPay'))
                        ->setAction($this->context->link->getModuleLink($this->name, 'payment', array(), true))
                        ->setAdditionalInformation($this->context->smarty->fetch('module:'.$this->name.'/views/templates/hook/payment_intro.tpl'));
        $payment_options = [
            $newOption,
        ];

        return $payment_options;
    }

    /******** TEMPLATE VARIABLES ********/
    public function getTemplateVarInfos()
    {
        $cart = $this->context->cart;
        $total = sprintf(
            $this->l('%1$s (tax incl.)'),
            Tools::displayPrice($cart->getOrderTotal(true, Cart::BOTH))
        );

        return array(
            'card_logos' => Media::getMediaPath(_PS_MODULE_DIR_.$this->name.'/views/img/'.$this->name.'-cards.png'),
            'total' => $total,
        );
    }

    /******** CREATE AND ADD PRIVATE MESSAGE TO AN ORDER ********/
    public function _addNewPrivateMessage($id_order, $id_cart, $id_customer, $message)
    {
        if (!(bool)$id_order) {
            return false;
        }

        $new_message = new Message();
        $message = str_replace("<br>", "\n", $message);

        if (!Validate::isCleanHtml($message)) {
            $message = $this->l('Payment message is not valid, please check GP WebPay module.');
        }

        $new_message->message = $message;
        $new_message->id_order = (int)$id_order;
        $new_message->id_cart = (int)$id_cart;
        $new_message->id_customer = (int)$id_customer;
        $new_message->private = 1;

        return $new_message->add();
    }

    /******** RENDER FORM - REQUIRED SETTINGS & CURRENCY #1 ********/
    public function renderFormCurrency1()
    {
        if (Configuration::get('GPWEBPAY_LIVE_FLAG') == '1') {
            $this->mode_text = $this->l('Private Key (Live)');
            $this->test_label = '';
        } else {
            $this->mode_text = $this->l('Private Key (Testing)');
            $this->test_label = '_TEST';
        }

        $fields_form = array(
            'form' => array(
                'legend' => array(
                    'title' => '&nbsp; '.$this->l('Module settings'),
                    'icon' => 'icon-money',
                ),
                'input' => array(
                    array(
                        'type' => 'switch',
                        'label' => $this->l('Allow Debugging mode'),
                        'desc' => $this->l('Use this option for testing purposes only. Must be set to "No" in production environment!'),
                        'name' => 'GPWEBPAY_DEBUG',
                        'values' => array(
                            array(
                                'id' => 'debug_on',
                                'value' => '1',
                                'label' => $this->l('Yes'),
                            ),
                            array(
                                'id' => 'debug_off',
                                'value' => '0',
                                'label' => $this->l('No'),
                            ),
                        ),
                    ),
                    array(
                        'type' => 'select',
                        'label' => $this->l('Payment currency'),
                        'name' => 'GPWEBPAY_CURRENCY',
                        'class' => 'fixed-width-xl',
                        'options' => array(
                            'query' => array(
                                array('id' => '', 'name' => $this->l('- choose currency -')),
                                array('id' => 'EUR', 'name' => $this->l('Euro')),
                                array('id' => 'CZK', 'name' => $this->l('Czech koruna')),
                                array('id' => 'GPB', 'name' => $this->l('Pound sterling')),
                                array('id' => 'USD', 'name' => $this->l('US Dollar')),
                                array('id' => 'HUF', 'name' => $this->l('Hungarian forint')),
                                array('id' => 'PLN', 'name' => $this->l('Polish złoty')),
                                array('id' => 'RUB', 'name' => $this->l('Russian ruble')),
                                    ),
                                    'id' => 'id',
                                    'name' => 'name',
                                    ),
                    ),
                    array(
                        'type' => 'text',
                        'label' => $this->l('Merchant Number'),
                        'hint' => $this->l('The unique merchant number provided by your bank (10 characters).'),
                        'name' => 'GPWEBPAY_MERCHANTNUMBER',
                        'required' => true,
                        'maxlength' => 10,
                        'class' => 'fixed-width-md',
                    ),
                    array(
                        'type' => 'text',
                        'label' => $this->l('Private key password'),
                        'hint' => $this->l('The password you chose for generating your private key.'),
                        'name' => 'GPWEBPAY_PASSWORD',
                        'required' => true,
                        'class' => 'fixed-width-md',
                    ),
                    array(
                        'type' => 'select',
                        'label' => $this->l('Bank'),
                        'name' => 'GPWEBPAY_BANK',
                        'required' => true,
                        'class' => 'fixed-width-xxl',
                        'options' => array(
                            'query' => array(
                                array('id' => 'undefined', 'name' => $this->l('- choose bank -')),
                                array('id' => 'KB', 'name' => $this->l('Komercni banka (Czech Republic)')),
                                array('id' => 'CSOB Sk', 'name' => $this->l('CSOB (Slovakia)')),
                                array('id' => 'SLSP', 'name' => $this->l('Slovenska sporitelna (Slovakia)')),
                                array('id' => 'CSP', 'name' => $this->l('Ceska sporitelna (Czech Republic)')),
                                array('id' => 'UB', 'name' => $this->l('UniCredit Bank (Czech Republic)')),
                                array('id' => 'RB', 'name' => $this->l('Raiffeisen bank (Czech Republic)')),
                                array('id' => 'LPB', 'name' => $this->l('Latvia Pasta bank')),
                                    ),
                                    'id' => 'id',
                                    'name' => 'name',
                                    ),
                    ),
                    array(
                        'type'   => 'radio', 
                        'label'  => $this->l('Working Mode'),
                        'name'   => 'GPWEBPAY_LIVE_FLAG',
                        'required'  => true,
                        'class'    => 't',
                        'values'   => array( 
                            array(
                                'id'    => 'live',
                                'value' => '1',
                                'label' => $this->l('Live'),
                            ),
                            array(
                            'id'    => 'testing',
                            'value' => '0',
                            'label' => $this->l('Testing'),
                            ),
                          ),
                        ),                    
                    array(
                        'type'   => 'radio', 
                        'label'  => $this->l('Payment processing Mode'),
                        'hint'   => $this->l('Allow automatically decrease received money from client account, or after validation.'),
                        'name'   => 'GPWEBPAY_DEPOSITFLAG',
                        'required'  => true,
                        'class'    => 't',
                        'values'   => array( 
                            array(
                                'id'    => 'automatic',
                                'value' => '1',
                                'label' => $this->l('Automatic (recommended)'),
                            ),
                            array(
                            'id'    => 'manual',
                            'value' => '0',
                            'label' => $this->l('Manual'),
                            ),
                          ),
                        ),
                    array(
                        'type' => 'textarea',
                        'label' => $this->l('Private Key (Live)'),
                        'placeholder' => $this->l('Paste Private Key from the .key file.'),
                        'hint' => $this->l('Paste Private Key from the .key file.'),
                        'name' => 'GPWEBPAY_PRIVATE_KEY',
                        'required' => true,
                        'lang' => false,
                    ),
                    array(
                        'type' => 'textarea',
                        'label' => $this->l('Private Key (Testing)'),
                        'placeholder' => $this->l('Paste Private Key from the .key file.'),
                        'hint' => $this->l('Paste Private Key from the .key file.'),
                        'name' => 'GPWEBPAY_PRIVATE_KEY_TEST',
                        'placeholder' => '09XXXXXXXX',
                        'required' => true,
                        'lang' => false,
                    ),
                ),
                'submit' => array(
                    'title' => $this->l('Save'),
                ),
            ),
        );
        
        $helper = new HelperForm();
        $helper->show_toolbar = false;
        $helper->table = $this->table;
        $lang = new Language((int)Configuration::get('PS_LANG_DEFAULT'));
        $helper->default_form_language = $lang->id;
        $helper->allow_employee_form_lang = Configuration::get('PS_BO_ALLOW_EMPLOYEE_FORM_LANG') ? : 0;
        $this->fields_form = array();
        $helper->id = (int)Tools::getValue('id_carrier');
        $helper->identifier = $this->identifier;
        $helper->submit_action = 'btnSubmitCurrency1';
        $helper->currentIndex = $this->context->link->getAdminLink('AdminModules', false).'&configure='.$this->name.'&tab_module='.$this->tab.'&module_name='.$this->name;
        $helper->token = Tools::getAdminTokenLite('AdminModules');
        $helper->tpl_vars = array(
            'fields_value' => $this->getConfigFieldsValues(),
            'languages' => $this->context->controller->getLanguages(),
            'id_language' => $this->context->language->id
        );

        return $helper->generateForm(array($fields_form));
    }

    /******** RENDER FORM - CURRENCY #2 ********/
    public function renderFormCurrency2()
    {

        if (Configuration::get('GPWEBPAY_LIVE_FLAG_2') == '1') {
            $this->mode_text = $this->l('Private Key (Live)');
            $this->test_label = '';
        } else {
            $this->mode_text = $this->l('Private Key (Testing)');
            $this->test_label = '_TEST';
        }

        if (Configuration::get('GPWEBPAY_ALLOW_CURRENCY_2') == '0') {
            $disaled_field = true;
        } else {
            $disaled_field = false;
        }

        $fields_form = array(
            'form' => array(
                'legend' => array(
                    'title' => '&nbsp; '.$this->l('2nd payment currency settings'),
                    'icon' => 'icon-money',
                ),
                'input' => array(
                    array(
                        'type'   => 'switch', 
                        'label'  => $this->l('Enable 2nd payment currency'),
                        'name'   => 'GPWEBPAY_ALLOW_CURRENCY_2',
                        'class'    => 't',
                        'values' => array(
                            array(
                                'id' => 'enable',
                                'value' => '1',
                                'label' => $this->l('Enabled'),
                            ),
                            array(
                                'id' => 'disable',
                                'value' => '0',
                                'label' => $this->l('Disabled'),
                            ),
                        ),
                    ),
                    array(
                        'type' => 'select',
                        'label' => $this->l('Payment currency'),
                        'name' => 'GPWEBPAY_CURRENCY_2',
                        'disabled' => $disaled_field,
//                      'required' => true,
                        'class' => 'fixed-width-xl',
                        'options' => array(
                            'query' => array(
                                array('id' => '', 'name' => $this->l('- choose currency -')),
                                array('id' => 'EUR', 'name' => $this->l('Euro')),
                                array('id' => 'CZK', 'name' => $this->l('Czech koruna')),
                                array('id' => 'GPB', 'name' => $this->l('Pound sterling')),
                                array('id' => 'USD', 'name' => $this->l('US Dollar')),
                                array('id' => 'HUF', 'name' => $this->l('Hungarian forint')),
                                array('id' => 'PLN', 'name' => $this->l('Polish złoty')),
                                array('id' => 'RUB', 'name' => $this->l('Russian ruble')),
                                    ),
                                    'id' => 'id',
                                    'name' => 'name',
                                    ),
                    ),
                    array(
                        'type' => 'text',
                        'label' => $this->l('Merchant Number'),
                        'hint' => $this->l('The unique merchant number provided by your bank (10 characters).'),
                        'name' => 'GPWEBPAY_MERCHANTNUMBER_2',
                        'disabled' => $disaled_field,
//                      'required' => true,
                        'maxlength' => 10,
                        'class' => 'fixed-width-md',
                    ),
                    array(
                        'type' => 'text',
                        'label' => $this->l('Private key password'),
                        'hint' => $this->l('The password you chose for generating your private key.'),
                        'name' => 'GPWEBPAY_PASSWORD_2',
                        'disabled' => $disaled_field,
//                      'required' => true,
                        'class' => 'fixed-width-md',
                    ),
                    array(
                        'type' => 'select',
                        'label' => $this->l('Bank'),
                        'name' => 'GPWEBPAY_BANK_2',
                        'disabled' => $disaled_field,
//                      'required' => true,
                        'class' => 'fixed-width-xxl',
                        'options' => array(
                            'query' => array(
                                array('id' => 'undefined', 'name' => $this->l('- choose bank -')),
                                array('id' => 'KB', 'name' => $this->l('Komercni banka (Czech Republic)')),
                                array('id' => 'CSOB', 'name' => $this->l('CSOB (Czech Republic)')),
                                array('id' => 'CSOB Sk', 'name' => $this->l('CSOB (Slovakia)')),
                                array('id' => 'SLSP', 'name' => $this->l('Slovenska sporitelna (Slovakia)')),
                                array('id' => 'CSP', 'name' => $this->l('Ceska sporitelna (Czech Republic)')),
                                array('id' => 'UB', 'name' => $this->l('UniCredit Bank (Czech Republic)')),
                                array('id' => 'RB', 'name' => $this->l('Raiffeisen bank (Czech Republic)')),
                                array('id' => 'LPB', 'name' => $this->l('Latvia Pasta bank')),
                                    ),
                                    'id' => 'id',
                                    'name' => 'name',
                                    ),
                    ),
                    array(
                        'type'   => 'radio', 
                        'label'  => $this->l('Working Mode'),
                        'name'   => 'GPWEBPAY_LIVE_FLAG_2',
                        'disabled' => $disaled_field,
//                      'required'  => true,
                        'class'    => 't',
                        'values'   => array( 
                            array(
                                'id'    => 'live',
                                'value' => '1',
                                'label' => $this->l('Live'),
                            ),
                            array(
                            'id'    => 'testing',
                            'value' => '0',
                            'label' => $this->l('Testing'),
                            ),
                          ),
                        ),                    
                    array(
                        'type'   => 'radio', 
                        'label'  => $this->l('Payment processing Mode'),
                        'hint'   => $this->l('Allow automatically decrease received money from client account, or after validation.'),
                        'name'   => 'GPWEBPAY_DEPOSITFLAG_2',
                        'disabled' => $disaled_field,
//                      'required'  => true,
                        'class'    => 't',
                        'values'   => array( 
                            array(
                                'id'    => 'automatic',
                                'value' => '1',
                                'label' => $this->l('Automatic (recommended)'),
                            ),
                            array(
                            'id'    => 'manual',
                            'value' => '0',
                            'label' => $this->l('Manual'),
                            ),
                          ),
                        ),
                    array(
                        'type' => 'textarea',
                        'label' => $this->l('Private Key (Live)'),
                        'hint' => $this->l('Paste Private Key from the .key file.'),
                        'name' => 'GPWEBPAY_PRIVATE_KEY_2',
                        'readonly' => $disaled_field,
//                      'required' => true,
                        'lang' => false,
                    ),
                    array(
                        'type' => 'textarea',
                        'label' => $this->l('Private Key (Testing)'),
                        'hint' => $this->l('Paste Private Key from the .key file.'),
                        'name' => 'GPWEBPAY_PRIVATE_KEY_TEST_2',
                        'readonly' => $disaled_field,
//                      'required' => true,
                        'lang' => false,
                    ),
                ),
                'submit' => array(
                    'title' => $this->l('Save'),
                ),
            ),
        );
        
        $helper = new HelperForm();
        $helper->show_toolbar = false;
        $helper->table = $this->table;
        $lang = new Language((int)Configuration::get('PS_LANG_DEFAULT'));
        $helper->default_form_language = $lang->id;
        $helper->allow_employee_form_lang = Configuration::get('PS_BO_ALLOW_EMPLOYEE_FORM_LANG') ? : 0;
        $this->fields_form = array();
        $helper->id = (int)Tools::getValue('id_carrier');
        $helper->identifier = $this->identifier;
        $helper->submit_action = 'btnSubmitCurrency2';
        $helper->currentIndex = $this->context->link->getAdminLink('AdminModules', false).'&configure='.$this->name.'&tab_module='.$this->tab.'&module_name='.$this->name;
        $helper->token = Tools::getAdminTokenLite('AdminModules');
        $helper->tpl_vars = array(
            'fields_value' => $this->getConfigFieldsValues(),
            'languages' => $this->context->controller->getLanguages(),
            'id_language' => $this->context->language->id
        );

        return $helper->generateForm(array($fields_form));
    }

    /******** RENDER FORM - CURRENCY #3 ********/
    public function renderFormCurrency3()
    {

        if (Configuration::get('GPWEBPAY_LIVE_FLAG_3') == '1') {
            $this->mode_text = $this->l('Private Key (Live)');
            $this->test_label = '';
        } else {
            $this->mode_text = $this->l('Private Key (Testing)');
            $this->test_label = '_TEST';
        }

        if (Configuration::get('GPWEBPAY_ALLOW_CURRENCY_3') == '0') {
            $disaled_field = true;
        } else {
            $disaled_field = false;
        }

        $fields_form = array(
            'form' => array(
                'legend' => array(
                    'title' => '&nbsp; '.$this->l('3rd payment currency settings'),
                    'icon' => 'icon-money',
                ),
                'input' => array(
                    array(
                        'type'   => 'switch', 
                        'label'  => $this->l('Enable 3rd payment currency'),
                        'name'   => 'GPWEBPAY_ALLOW_CURRENCY_3',
                        'class'    => 't',
                        'values' => array(
                            array(
                                'id' => 'enable',
                                'value' => '1',
                                'label' => $this->l('Enabled'),
                            ),
                            array(
                                'id' => 'disable',
                                'value' => '0',
                                'label' => $this->l('Disabled'),
                            ),
                        ),
                    ),
                    array(
                        'type' => 'select',
                        'label' => $this->l('Payment currency'),
                        'name' => 'GPWEBPAY_CURRENCY_3',
                        'disabled' => $disaled_field,
//                      'required' => true,
                        'class' => 'fixed-width-xl',
                        'options' => array(
                            'query' => array(
                                array('id' => '', 'name' => $this->l('- choose currency -')),
                                array('id' => 'EUR', 'name' => $this->l('Euro')),
                                array('id' => 'CZK', 'name' => $this->l('Czech koruna')),
                                array('id' => 'GPB', 'name' => $this->l('Pound sterling')),
                                array('id' => 'USD', 'name' => $this->l('US Dollar')),
                                array('id' => 'HUF', 'name' => $this->l('Hungarian forint')),
                                array('id' => 'PLN', 'name' => $this->l('Polish złoty')),
                                array('id' => 'RUB', 'name' => $this->l('Russian ruble')),
                                    ),
                                    'id' => 'id',
                                    'name' => 'name',
                                    ),
                    ),
                    array(
                        'type' => 'text',
                        'label' => $this->l('Merchant Number'),
                        'hint' => $this->l('The unique merchant number provided by your bank (10 characters).'),
                        'name' => 'GPWEBPAY_MERCHANTNUMBER_3',
                        'disabled' => $disaled_field,
//                      'required' => true,
                        'maxlength' => 10,
                        'class' => 'fixed-width-md',
                    ),
                    array(
                        'type' => 'text',
                        'label' => $this->l('Private key password'),
                        'hint' => $this->l('The password you chose for generating your private key.'),
                        'name' => 'GPWEBPAY_PASSWORD_3',
                        'disabled' => $disaled_field,
//                      'required' => true,
                        'class' => 'fixed-width-md',
                    ),
                    array(
                        'type' => 'select',
                        'label' => $this->l('Bank'),
                        'name' => 'GPWEBPAY_BANK_3',
                        'disabled' => $disaled_field,
//                      'required' => true,
                        'class' => 'fixed-width-xxl',
                        'options' => array(
                            'query' => array(
                                array('id' => 'undefined', 'name' => $this->l('- choose bank -')),
                                array('id' => 'KB', 'name' => $this->l('Komercni banka (Czech Republic)')),
                                array('id' => 'CSOB', 'name' => $this->l('CSOB (Czech Republic)')),
                                array('id' => 'CSOB Sk', 'name' => $this->l('CSOB (Slovakia)')),
                                array('id' => 'SLSP', 'name' => $this->l('Slovenska sporitelna (Slovakia)')),
                                array('id' => 'CSP', 'name' => $this->l('Ceska sporitelna (Czech Republic)')),
                                array('id' => 'UB', 'name' => $this->l('UniCredit Bank (Czech Republic)')),
                                array('id' => 'RB', 'name' => $this->l('Raiffeisen bank (Czech Republic)')),
                                array('id' => 'LPB', 'name' => $this->l('Latvia Pasta bank')),
                                    ),
                                    'id' => 'id',
                                    'name' => 'name',
                                    ),
                    ),
                    array(
                        'type'   => 'radio', 
                        'label'  => $this->l('Working Mode'),
                        'name'   => 'GPWEBPAY_LIVE_FLAG_3',
                        'disabled' => $disaled_field,
//                      'required'  => true,
                        'class'    => 't',
                        'values'   => array( 
                            array(
                                'id'    => 'live',
                                'value' => '1',
                                'label' => $this->l('Live'),
                            ),
                            array(
                            'id'    => 'testing',
                            'value' => '0',
                            'label' => $this->l('Testing'),
                            ),
                          ),
                        ),                    
                    array(
                        'type'   => 'radio', 
                        'label'  => $this->l('Payment processing Mode'),
                        'hint'   => $this->l('Allow automatically decrease received money from client account, or after validation.'),
                        'name'   => 'GPWEBPAY_DEPOSITFLAG_3',
                        'disabled' => $disaled_field,
//                      'required'  => true,
                        'class'    => 't',
                        'values'   => array( 
                            array(
                                'id'    => 'automatic',
                                'value' => '1',
                                'label' => $this->l('Automatic (recommended)'),
                            ),
                            array(
                            'id'    => 'manual',
                            'value' => '0',
                            'label' => $this->l('Manual'),
                            ),
                          ),
                        ),
                    array(
                        'type' => 'textarea',
                        'label' => $this->l('Private Key (Live)'),
                        'hint' => $this->l('Paste Private Key from the .key file.'),
                        'name' => 'GPWEBPAY_PRIVATE_KEY_3',
                        'readonly' => $disaled_field,
//                      'required' => true,
                        'lang' => false,
                    ),
                    array(
                        'type' => 'textarea',
                        'label' => $this->l('Private Key (Testing)'),
                        'hint' => $this->l('Paste Private Key from the .key file.'),
                        'name' => 'GPWEBPAY_PRIVATE_KEY_TEST_3',
                        'readonly' => $disaled_field,
//                      'required' => true,
                        'lang' => false,
                    ),
                ),
                'submit' => array(
                    'title' => $this->l('Save'),
                ),
            ),
        );
        
        $helper = new HelperForm();
        $helper->show_toolbar = false;
        $helper->table = $this->table;
        $lang = new Language((int)Configuration::get('PS_LANG_DEFAULT'));
        $helper->default_form_language = $lang->id;
        $helper->allow_employee_form_lang = Configuration::get('PS_BO_ALLOW_EMPLOYEE_FORM_LANG') ? : 0;
        $this->fields_form = array();
        $helper->id = (int)Tools::getValue('id_carrier');
        $helper->identifier = $this->identifier;
        $helper->submit_action = 'btnSubmitCurrency3';
        $helper->currentIndex = $this->context->link->getAdminLink('AdminModules', false).'&configure='.$this->name.'&tab_module='.$this->tab.'&module_name='.$this->name;
        $helper->token = Tools::getAdminTokenLite('AdminModules');
        $helper->tpl_vars = array(
            'fields_value' => $this->getConfigFieldsValues(),
            'languages' => $this->context->controller->getLanguages(),
            'id_language' => $this->context->language->id
        );

        return $helper->generateForm(array($fields_form));
    }


    /******** RENDER FORM 4 ********/
    public function renderFormCurrencyOther()
    {
        $fields_form = array(
            'form' => array(
                'legend' => array(
                    'title' => '&nbsp; '.$this->l('Even more payment currencies'),
                    'icon' => 'icon-money',
                ),
                'input' => array(
                    array(
                        'type'   => 'switch', 
                        'label'  => $this->l('Allow payments in other currencies'),
                        'desc'   => $this->l('If you set "Yes", the prices will by converted to default currency.'),
                        'name'   => 'GPWEBPAY_ALLOW_OTHER_CURRENCIES',
                        'required'  => false,
                        'class'    => 't',
                        'values' => array(
                            array(
                                'id' => 'allow',
                                'value' => '1',
                                'label' => $this->l('Enabled'),
                            ),
                            array(
                                'id' => 'dontallow',
                            'value' => '0',
                                'label' => $this->l('Disabled'),
                            ),
                        ),
                    ),
                    
                ),
                'submit' => array(
                    'title' => $this->l('Save'),
                ),
            ),
        );
        
        $helper = new HelperForm();
        $helper->show_toolbar = false;
        $helper->table = $this->table;
        $lang = new Language((int)Configuration::get('PS_LANG_DEFAULT'));
        $helper->default_form_language = $lang->id;
        $helper->allow_employee_form_lang = Configuration::get('PS_BO_ALLOW_EMPLOYEE_FORM_LANG') ? : 0;
        $this->fields_form = array();
        $helper->id = (int)Tools::getValue('id_carrier');
        $helper->identifier = $this->identifier;
        $helper->submit_action = 'btnSubmitOtherCurrency';
        $helper->currentIndex = $this->context->link->getAdminLink('AdminModules', false).'&configure='.$this->name.'&tab_module='.$this->tab.'&module_name='.$this->name;
        $helper->token = Tools::getAdminTokenLite('AdminModules');
        $helper->tpl_vars = array(
            'fields_value' => $this->getConfigFieldsValues(),
            'languages' => $this->context->controller->getLanguages(),
            'id_language' => $this->context->language->id
        );

        return $helper->generateForm(array($fields_form));
    }

    /******** RENDER FORM - ORDER SETTINGS ********/
    public function renderFormOrder()
    {
        $statuses = OrderState::getOrderStates($this->context->language->id);

        $statuses_awaiting_list = array(
            0 => array(
                'id' => 0,
                'name' => $this->l('-- select an order status --'),
            )
        );

        foreach ($statuses as $status_awaiting) {
            $statuses_awaiting_list[] = array(
                'id' => $status_awaiting['id_order_state'],
                'name' => $status_awaiting['id_order_state'] == Configuration::get('GPWEBPAY_OS_AWAITING') ? $status_awaiting['name'].' &nbsp; [*]' : $status_awaiting['name'],
            );
        }

        $statuses_ok_list = array(
            0 => array(
                'id' => 0,
                'name' => $this->l('-- select an order status --'),
            )
        );

        foreach ($statuses as $status) {
            $statuses_ok_list[] = array(
                'id' => $status['id_order_state'],
                'name' => $status['id_order_state'] == 2 ? $status['name'].' &nbsp; [*]' : $status['name'],
            );
        }

        $statuses_fail_list = array(
            0 => array(
                'id' => 0,
                'name' => $this->l('-- select an order status --'),
            )
        );

        foreach ($statuses as $status_fail) {
            $statuses_fail_list[] = array(
                'id' => $status_fail['id_order_state'],
                'name' => $status_fail['id_order_state'] == 8 ? $status_fail['name'].' &nbsp; [*]' : $status_fail['name'],
            );
        }

        $fields_form = array(
            'form' => array(
                'legend' => array(
                    'title' => '&nbsp; '.$this->l('Order settings'),
                    'icon' => 'icon-flag',
                ),
                'input' => array(
                    array(
                        'type'   => 'radio', 
                        'label'  => $this->l('Order method'),
                        'name'   => 'GPWEBPAY_ORDER_METHOD',
                        'required'  => true,
                        'class'    => 't',
                        'values'   => array( 
                            array(
                                'id'    => 'before',
                                'value' => 'before',
                                'label' => '<strong>'.$this->l('place an order before the payment').'</strong> &nbsp;'.$this->l('(recommended)').'<br>'.$this->l('(the transaction identifier is Order ID)'),
                            ),
                            array(
                                'id'    => 'after',
                                'value' => 'after',
                                'label' => '<strong>'.$this->l('place an order after the payment').'</strong><br>'.$this->l('(the transaction identifier is Cart ID)'),
                            ),
                        ),
                    ),
                    array(
                        'type' => 'select',
                        'label' => $this->l('Awaiting payment order status'),
                        'hint' => $this->l('Default payment status is "Awaiting GP WebPay payment".'),
                        'desc' => $this->l('This order status is availabe for "place an order before the payment" order method only.'),
                        'name' => 'GPWEBPAY_STATUS_AWAITING',
                        'required' => true,
                        'default_value' => Configuration::get('GPWEBPAY_OS_AWAITING'),
                        'class' => 'fixed-width-xxl',
                        'options' => array(
                            'query' => $statuses_awaiting_list,
                            'id' => 'id',
                            'name' => 'name',
                        ),
                    ),
                    array(
                        'type' => 'select',
                        'label' => $this->l('Success payment order status'),
                        'hint' => $this->l('Default payment status is "Payment accepted".'),
                        'name' => 'GPWEBPAY_STATUS_OK',
                        'required' => true,
                        'default_value' => '2',
                        'class' => 'fixed-width-xxl',
                        'options' => array(
                            'query' => $statuses_ok_list,
                            'id' => 'id',
                            'name' => 'name',
                        ),
                    ),
                    array(
                        'type' => 'select',
                        'label' => $this->l('Error payment order status'),
                        'hint' => $this->l('Default payment status is "Payment error".'),
                        'name' => 'GPWEBPAY_STATUS_FAIL',
                        'required' => true,
                        'default_value' => '8',
                        'class' => 'fixed-width-xxl',
                        'options' => array(
                            'query' => $statuses_fail_list,
                            'id' => 'id',
                            'name' => 'name',
                        ),
                    ),
                ),
                'submit' => array(
                    'title' => $this->l('Save'),
                ),
            ),
        );

        $helper = new HelperForm();
        $helper->show_toolbar = false;
        $helper->table = $this->table;
        $lang = new Language((int)Configuration::get('PS_LANG_DEFAULT'));
        $helper->default_form_language = $lang->id;
        $helper->allow_employee_form_lang = Configuration::get('PS_BO_ALLOW_EMPLOYEE_FORM_LANG') ? : 0;
        $this->fields_form = array();
        $helper->id = (int)Tools::getValue('id_carrier');
        $helper->identifier = $this->identifier;
        $helper->submit_action = 'btnSubmitOrder';
        $helper->currentIndex = $this->context->link->getAdminLink('AdminModules', false).'&configure='.$this->name.'&tab_module='.$this->tab.'&module_name='.$this->name;
        $helper->token = Tools::getAdminTokenLite('AdminModules');
        $helper->tpl_vars = array(
            'fields_value' => $this->getConfigFieldsValues(),
            'languages' => $this->context->controller->getLanguages(),
            'id_language' => $this->context->language->id
        );

        return $helper->generateForm(array($fields_form));
    }

    /******** RENDER FORM - DESIGN SETTINGS ********/
    public function renderFormIcon()
    {
        $fields_form = array(
            'form' => array(
                'legend' => array(
                    'title' => '&nbsp; '.$this->l('Design settings'),
                    'icon' => 'icon-paint-brush',
                ),
                'input' => array(
                    array(
                        'type'   => 'radio', 
                        'label'  => $this->l('Payment icon'),
                        'desc'   => '<img src="'.Media::getMediaPath(_PS_MODULE_DIR_.$this->name.'/views/img/'.$this->name.'-logo.png').'" style="border:none; margin:10px 0" alt="'.$this->l('Payment icon image').'">',
                        'name'   => 'GPWEBPAY_ICON',
                        'required'  => false,
                        'class'    => 't',
                        'values'   => array( 
                            array(
                                'id'    => 'no',
                                'value' => '0',
                                'label' => $this->l('not display'),
                            ),
                            array(
                                'id'    => 'product',
                                'value' => 'p',
                                'label' => $this->l('display in product detail'),
                            ),
                            array(
                                'id'    => 'left',
                                'value' => 'l',
                                'label' => $this->l('display in left column'),
                            ),
                            array(
                            'id'    => 'right',
                            'value' => 'r',
                            'label' => $this->l('display in right column'),
                        ),
                      ),
                    ),
                    array(
                        'type'   => 'switch', 
                        'label'  => $this->l('Show credit / debet card logos'),
                        'hint'  => $this->l('These logos will be dysplayed in the Front Office and in the shopping cart\'s payment methods list.'),
                        'desc'   => '<img src="'.Media::getMediaPath(_PS_MODULE_DIR_.$this->name.'/views/img/'.$this->name.'-cards.png').'" style="border:none; margin:10px 0" alt="'.$this->l('Logo image').'"><br>'.$this->l('Editable icon file is available in the "docs" module folder.'),
                        'name'   => 'GPWEBPAY_CARDICON',
                        'required'  => false,
                        'class'    => 't',
                        'values' => array(
                            array(
                                'id' => 'cardicon_on',
                                'value' => '1',
                                'label' => $this->l('Enabled'),
                            ),
                            array(
                                'id' => 'cardicon_off',
                                'value' => '0',
                                'label' => $this->l('Disabled'),
                            ),
                        ),
                    ),
                    array(
                        'type' => 'select',
                        'label' => $this->l('Payment icon destination CMS page'),
                        'hint'  => $this->l('Select CMS page where will follow link from the icon.'),
                        'name' => 'GPWEBPAY_CMS_ID',
                        'required' => false,
                        'default_value' => '3',
                        'options' => array(
                            'query' => CMS::listCms($this->context->language->id),
                            'id' => 'id_cms',
                            'name' => 'meta_title',
                        ),
                    ),
                ),
                'submit' => array(
                    'title' => $this->l('Save'),
                ),
            ),
        );
        
        $helper = new HelperForm();
        $helper->show_toolbar = false;
        $helper->table = $this->table;
        $lang = new Language((int)Configuration::get('PS_LANG_DEFAULT'));
        $helper->default_form_language = $lang->id;
        $helper->allow_employee_form_lang = Configuration::get('PS_BO_ALLOW_EMPLOYEE_FORM_LANG') ? : 0;
        $this->fields_form = array();
        $helper->id = (int)Tools::getValue('id_carrier');
        $helper->identifier = $this->identifier;
        $helper->submit_action = 'btnSubmitIcon';
        $helper->currentIndex = $this->context->link->getAdminLink('AdminModules', false).'&configure='.$this->name.'&tab_module='.$this->tab.'&module_name='.$this->name;
        $helper->token = Tools::getAdminTokenLite('AdminModules');
        $helper->tpl_vars = array(
            'fields_value' => $this->getConfigFieldsValues(),
            'languages' => $this->context->controller->getLanguages(),
            'id_language' => $this->context->language->id
        );

        return $helper->generateForm(array($fields_form));
    }

    /******** GET FIELD VALUES ********/
    public function getConfigFieldsValues()
    {
        return array(
            'GPWEBPAY_DEBUG' => Tools::getValue('GPWEBPAY_DEBUG', Configuration::get('GPWEBPAY_DEBUG')),
            'GPWEBPAY_CURRENCY' => Tools::getValue('GPWEBPAY_CURRENCY', Configuration::get('GPWEBPAY_CURRENCY')),
            'GPWEBPAY_MERCHANTNUMBER' => Tools::getValue('GPWEBPAY_MERCHANTNUMBER', Configuration::get('GPWEBPAY_MERCHANTNUMBER')),
            'GPWEBPAY_PASSWORD' => Tools::getValue('GPWEBPAY_PASSWORD', Configuration::get('GPWEBPAY_PASSWORD')),
            'GPWEBPAY_BANK' => Tools::getValue('GPWEBPAY_BANK', Configuration::get('GPWEBPAY_BANK')),
            'GPWEBPAY_LIVE_FLAG' => Tools::getValue('GPWEBPAY_LIVE_FLAG', Configuration::get('GPWEBPAY_LIVE_FLAG')),
            'GPWEBPAY_DEPOSITFLAG' => Tools::getValue('GPWEBPAY_DEPOSITFLAG', Configuration::get('GPWEBPAY_DEPOSITFLAG')),
            'GPWEBPAY_PRIVATE_KEY' => Tools::getValue('GPWEBPAY_PRIVATE_KEY', Configuration::get('GPWEBPAY_PRIVATE_KEY')),
            'GPWEBPAY_PRIVATE_KEY_TEST' => Tools::getValue('GPWEBPAY_PRIVATE_KEY_TEST', Configuration::get('GPWEBPAY_PRIVATE_KEY_TEST')),

            'GPWEBPAY_ALLOW_CURRENCY_2' => Tools::getValue('GPWEBPAY_ALLOW_CURRENCY_2', Configuration::get('GPWEBPAY_ALLOW_CURRENCY_2')),
            'GPWEBPAY_CURRENCY_2' => Tools::getValue('GPWEBPAY_CURRENCY_2', Configuration::get('GPWEBPAY_CURRENCY_2')),
            'GPWEBPAY_MERCHANTNUMBER_2' => Tools::getValue('GPWEBPAY_MERCHANTNUMBER_2', Configuration::get('GPWEBPAY_MERCHANTNUMBER_2')),
            'GPWEBPAY_PASSWORD_2' => Tools::getValue('GPWEBPAY_PASSWORD_2', Configuration::get('GPWEBPAY_PASSWORD_2')),
            'GPWEBPAY_BANK_2' => Tools::getValue('GPWEBPAY_BANK_2', Configuration::get('GPWEBPAY_BANK_2')),
            'GPWEBPAY_LIVE_FLAG_2' => Tools::getValue('GPWEBPAY_LIVE_FLAG_2', Configuration::get('GPWEBPAY_LIVE_FLAG_2')),
            'GPWEBPAY_DEPOSITFLAG_2' => Tools::getValue('GPWEBPAY_DEPOSITFLAG_2', Configuration::get('GPWEBPAY_DEPOSITFLAG_2')),
            'GPWEBPAY_PRIVATE_KEY_2' => Tools::getValue('GPWEBPAY_PRIVATE_KEY_2', Configuration::get('GPWEBPAY_PRIVATE_KEY_2')),
            'GPWEBPAY_PRIVATE_KEY_TEST_2' => Tools::getValue('GPWEBPAY_PRIVATE_KEY_TEST_2', Configuration::get('GPWEBPAY_PRIVATE_KEY_TEST_2')),

            'GPWEBPAY_ALLOW_CURRENCY_3' => Tools::getValue('GPWEBPAY_ALLOW_CURRENCY_3', Configuration::get('GPWEBPAY_ALLOW_CURRENCY_3')),
            'GPWEBPAY_CURRENCY_3' => Tools::getValue('GPWEBPAY_CURRENCY_3', Configuration::get('GPWEBPAY_CURRENCY_3')),
            'GPWEBPAY_MERCHANTNUMBER_3' => Tools::getValue('GPWEBPAY_MERCHANTNUMBER_3', Configuration::get('GPWEBPAY_MERCHANTNUMBER_3')),
            'GPWEBPAY_PASSWORD_3' => Tools::getValue('GPWEBPAY_PASSWORD_3', Configuration::get('GPWEBPAY_PASSWORD_3')),
            'GPWEBPAY_BANK_3' => Tools::getValue('GPWEBPAY_BANK_3', Configuration::get('GPWEBPAY_BANK_3')),
            'GPWEBPAY_LIVE_FLAG_3' => Tools::getValue('GPWEBPAY_LIVE_FLAG_3', Configuration::get('GPWEBPAY_LIVE_FLAG_3')),
            'GPWEBPAY_DEPOSITFLAG_3' => Tools::getValue('GPWEBPAY_DEPOSITFLAG_3', Configuration::get('GPWEBPAY_DEPOSITFLAG_3')),
            'GPWEBPAY_PRIVATE_KEY_3' => Tools::getValue('GPWEBPAY_PRIVATE_KEY_3', Configuration::get('GPWEBPAY_PRIVATE_KEY_3')),
            'GPWEBPAY_PRIVATE_KEY_TEST_3' => Tools::getValue('GPWEBPAY_PRIVATE_KEY_TEST_3', Configuration::get('GPWEBPAY_PRIVATE_KEY_TEST_3')),

            'GPWEBPAY_ALLOW_OTHER_CURRENCIES' => Tools::getValue('GPWEBPAY_ALLOW_OTHER_CURRENCIES', Configuration::get('GPWEBPAY_ALLOW_OTHER_CURRENCIES')),

            'GPWEBPAY_ORDER_METHOD' => Tools::getValue('GPWEBPAY_ORDER_METHOD', Configuration::get('GPWEBPAY_ORDER_METHOD')),
            'GPWEBPAY_STATUS_AWAITING' => Tools::getValue('GPWEBPAY_STATUS_AWAITING', Configuration::get('GPWEBPAY_STATUS_AWAITING')),
            'GPWEBPAY_STATUS_OK' => Tools::getValue('GPWEBPAY_STATUS_OK', Configuration::get('GPWEBPAY_STATUS_OK')),
            'GPWEBPAY_STATUS_FAIL' => Tools::getValue('GPWEBPAY_STATUS_FAIL', Configuration::get('GPWEBPAY_STATUS_FAIL')),

            'GPWEBPAY_ICON' => Tools::getValue('GPWEBPAY_ICON', Configuration::get('GPWEBPAY_ICON')),
            'GPWEBPAY_CARDICON' => Tools::getValue('GPWEBPAY_CARDICON', Configuration::get('GPWEBPAY_CARDICON')),
            'GPWEBPAY_CMS_ID' => Tools::getValue('GPWEBPAY_CMS_ID', Configuration::get('GPWEBPAY_CMS_ID')),
        );
    }

    /******** NOTIFICATION ********/
    public function _notifyMe()
    {
        $this->authormail = 'info@jlprestashop.cz';
        $data = array("{ps_version}" => "PrestaShop "._PS_VERSION_, "{ps_email}" => Configuration::get('PS_SHOP_EMAIL'), "{ps_url}" => $_SERVER['SERVER_NAME'], "{mod_name}" => $this->displayName, "{mod_version}" => $this->version, "{admin_name}" => $this->context->employee->firstname.' '.$this->context->employee->lastname, "{admin_email}" => $this->context->employee->email, "{date}" => date(d).'.'.date(m).'.'.date(Y).', '.date(H).':'.date(i).':'.date(s)
        );

        Mail::Send(Configuration::get('PS_LANG_DEFAULT'), 'notification', 'MOD: '.$this->displayName.' '.$this->version, $data, $this->authormail, null, null, null, null, null, _PS_MODULE_DIR_.$this->name.'/mails/', false, $this->context->shop->id);
    }

    /******** CSS ********/
    public function hookDisplayHeader($params)
    {
        $this->context->controller->addCSS(($this->_path).'views/css/'.$this->name.'.css', 'all');
    }

    /******** ICON TEMPLATE VARIABLES ********/
    public function getIconVariables()
    {
        return array(
            'icon_position' => Configuration::get('GPWEBPAY_ICON'),
            'icon_cards' => Configuration::get('GPWEBPAY_CARDICON'),
            'cms_link' => $this->context->link->getCMSLink((int)Configuration::get('GPWEBPAY_CMS_ID')),
            'logo_image' => Media::getMediaPath(_PS_MODULE_DIR_.$this->name.'/views/img/'.$this->name.'-logo.png'),
            'logo_cards' => Media::getMediaPath(_PS_MODULE_DIR_.$this->name.'/views/img/'.$this->name.'-cards.png'),
        );
    }

    /******** PAYMENT ICON - LEFT COLUMN ********/
    public function hookLeftColumn($params)
    {
        $this->context->smarty->assign(
            $this->getIconVariables()
        );

        return $this->display(__FILE__, 'icon_left.tpl');
    }

    /******** PAYMENT ICON - RIGHT COLUMN ********/
    public function hookRightColumn($params)
    {
        $this->context->smarty->assign(
            $this->getIconVariables()
        );

        return $this->display(__FILE__, 'icon_right.tpl');
    }

    /******** PAYMENT ICON - PRODUCT DETAIL ********/
    public function hookDisplayProductButtons($params)
    {
        $this->context->smarty->assign(
            $this->getIconVariables()
        );

        return $this->display(__FILE__, 'icon_product.tpl');
    }

    /******** MESSAGE NOTIFICATIONS ********/
    public function getL($key)
    {
        $translations = array(
            'payment_descr' => $this->l('Platba z eshopu Tany.sk'),
            'msg_payment' => $this->l('Awaiting GP WebPay card payment'),

            'msg_paymentinfo' => $this->l('GP WEBPAY TRANSACTION INFO'),
            'msg_resulttext' => $this->l('Result text:'),
            'msg_md' => $this->l('Cart ID:'),
            'msg_merordernum' => $this->l('Order ID:'),
            'msg_ordernumber' => $this->l('Timestamp:'),
            'msg_prcode' => $this->l('PR code:'),
            'msg_srcode' => $this->l('SR code:'),

            'msg_ok' => $this->l('GP WebPay payment processed successfully.'),
            'msg_fail' => $this->l('GP WebPay payment was not processed.'),
            'msg_verify' => $this->l('GP WebPay transaction was not verified.'),
            'msg_not_verified'  => $this->l('Signature verification was not successfull.'),

            'msg_error_operation' => $this->l('OPERATION parameter was not specified or had no "CREATE_ORDER" value.'),
            'msg_error_ordernumber' => $this->l('Timestamp was not specified.'),
            'msg_error_merordernum' => $this->l('Order number was not specified.'),
            'msg_error_prcode' => $this->l('Primary return code (PRCODE) was not specified.'),
            'msg_error_srcode' => $this->l('Secondary return code (SRCODE) was not specified.'),
            'msg_error_md' => $this->l('Cart ID was not specified.'),
            'msg_error_digest' => $this->l('Signature was not specified.'),
            'msg_error_digest1' => $this->l('Signature 1 was not specified.'),

            /* PR Codes: Reasons */
            'msg_prcode_0' => $this->l('OK'),
            'msg_prcode_1' => $this->l('Field too long'),
            'msg_prcode_2' => $this->l('Field too short'),
            'msg_prcode_3' => $this->l('Incorrect content of field'),
            'msg_prcode_4' => $this->l('Field is null'),
            'msg_prcode_5' => $this->l('Missing required field'),
            'msg_prcode_11' => $this->l('Unknown merchant'),
            'msg_prcode_14' => $this->l('Duplicate order number'),
            'msg_prcode_15' => $this->l('Object not found'),
            'msg_prcode_17' => $this->l('Amount to deposit exceeds approved amount'),
            'msg_prcode_18' => $this->l('Total sum of credited amounts exceeded deposited amount'),
            'msg_prcode_20' => $this->l('Object not in valid state for operation'),
            'msg_prcode_25' => $this->l('Operation not allowed for user'),
            'msg_prcode_26' => $this->l('Technical problem in connection to authorization center'),
            'msg_prcode_27' => $this->l('Incorrect order type'),
            'msg_prcode_28' => $this->l('Declined in 3D'),
            'msg_prcode_30' => $this->l('Declined in AC'),
            'msg_prcode_31' => $this->l('Wrong digest'),
            'msg_prcode_35' => $this->l('Session expired'),
            'msg_prcode_50' => $this->l('The cardholder canceled the payment'),
            'msg_prcode_200' => $this->l('Additional info request'),
            'msg_prcode_1000' => $this->l('Technical problem'),
            'msg_prcode_unknown' => $this->l('Unknown PR code'),
            'msg_srcode_unknown' => $this->l('Unknown SR code'),

            /* SR Codes: Reasons */
            'msg_srcode_0' => $this->l('No meaning'),
            'msg_srcode_1' => $this->l('ORDERNUMBER'),
            'msg_srcode_2' => $this->l('MERCHANTNUMBER'),
            'msg_srcode_6' => $this->l('AMOUNT'),
            'msg_srcode_7' => $this->l('CURRENCY'),
            'msg_srcode_8' => $this->l('DEPOSITFLAG'),
            'msg_srcode_10' => $this->l('MERORDERNUM'),
            'msg_srcode_11' => $this->l('CREDITNUMBER'),
            'msg_srcode_12' => $this->l('OPERATION'),
            'msg_srcode_18' => $this->l('BATCH'),
            'msg_srcode_22' => $this->l('ORDER'),
            'msg_srcode_24' => $this->l('URL'),
            'msg_srcode_25' => $this->l('MD'),
            'msg_srcode_26' => $this->l('DESC'),
            'msg_srcode_34' => $this->l('DIGEST'),

            'msg_srcode_3000' => $this->l('Declined in 3D. Cardholder not authenticated in 3D.'),
            'msg_srcode_3001' => $this->l('Authenticated'),
            'msg_srcode_3002' => $this->l('Not Authenticated in 3D. Issuer or Cardholder not participating in 3D.'),
            'msg_srcode_3004' => $this->l('Not Authenticated in 3D. Issuer not participating or Cardholder not enrolled.'),
            'msg_srcode_3005' => $this->l('Declined in 3D. Technical problem during Cardholder authentication.'),
            'msg_srcode_3006' => $this->l('Declined in 3D. Technical problem during Cardholder authentication.'),
            'msg_srcode_3007' => $this->l('Declined in 3D. Acquirer technical problem. Contact the merchant.'),
            'msg_srcode_3008' => $this->l('Declined in 3D. Unsupported card product.'),

            'msg_srcode_1001' => $this->l('Declined in AC, Card blocked'),
            'msg_srcode_1002' => $this->l('Declined in AC, Declined'),
            'msg_srcode_1003' => $this->l('Declined in AC, Card problem'),
            'msg_srcode_1004' => $this->l('Declined in AC, Technical problem in authorization process'),
            'msg_srcode_1005' => $this->l('Declined in AC, Account problem'),
        );

        return $translations[$key];
    }
}